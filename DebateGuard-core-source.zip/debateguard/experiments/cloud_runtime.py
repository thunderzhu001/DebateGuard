from __future__ import annotations

import csv
import hashlib
import json
import os
import sqlite3
from pathlib import Path
from typing import Any, Iterable


def shard_index_for_run(run_id: str, shard_count: int) -> int:
    if shard_count <= 0:
        raise ValueError("shard_count must be positive")
    digest = hashlib.sha256(run_id.encode("utf-8")).hexdigest()
    return int(digest[:16], 16) % shard_count


def runs_for_shard(
    runs: Iterable[dict[str, Any]], *, shard_count: int, shard_index: int
) -> list[dict[str, Any]]:
    if shard_index < 0 or shard_index >= shard_count:
        raise ValueError("shard_index must be in [0, shard_count)")
    return [
        run
        for run in runs
        if shard_index_for_run(str(run["run_id"]), shard_count) == shard_index
    ]


def checkpoint_path(checkpoint_dir: Path, run_id: str) -> Path:
    return checkpoint_dir / f"{run_id}.json"


def valid_checkpoint_rows(
    path: Path, run: dict[str, Any]
) -> list[dict[str, Any]] | None:
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    rows = payload.get("rows", []) if isinstance(payload, dict) else []
    expected = int(run.get("trace_count", 1) or 1)
    run_id = str(run["run_id"])
    if len(rows) != expected:
        return None
    if any(str(row.get("parent_run_id") or row.get("run_id")) != run_id for row in rows):
        return None
    result_ids = [str(row.get("run_id", "")) for row in rows]
    if any(not value for value in result_ids) or len(result_ids) != len(set(result_ids)):
        return None
    return rows


def write_parent_checkpoint(
    checkpoint_dir: Path,
    run: dict[str, Any],
    rows: list[dict[str, Any]],
    *,
    worker_id: str,
) -> Path:
    expected = int(run.get("trace_count", 1) or 1)
    if len(rows) != expected:
        raise ValueError(f"checkpoint rows={len(rows)}, expected={expected}")
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    path = checkpoint_path(checkpoint_dir, str(run["run_id"]))
    payload = {
        "schema_version": "debateguard_parent_checkpoint_v1",
        "parent_run_id": str(run["run_id"]),
        "trace_count": expected,
        "worker_id": worker_id,
        "rows": rows,
    }
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    with tmp.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, ensure_ascii=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)
    return path


def completed_checkpoint_run_ids(
    checkpoint_dir: Path, runs: Iterable[dict[str, Any]]
) -> set[str]:
    completed = set()
    for run in runs:
        run_id = str(run["run_id"])
        if valid_checkpoint_rows(checkpoint_path(checkpoint_dir, run_id), run) is not None:
            completed.add(run_id)
    return completed


def migrate_legacy_results(
    results_jsonl: Path,
    checkpoint_dir: Path,
    plan_runs: Iterable[dict[str, Any]],
) -> int:
    if not results_jsonl.exists():
        return 0
    plan_by_id = {str(run["run_id"]): run for run in plan_runs}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for line in results_jsonl.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        run_id = str(row.get("parent_run_id") or row.get("run_id", ""))
        if run_id in plan_by_id:
            grouped.setdefault(run_id, []).append(row)
    migrated = 0
    for run_id, rows in grouped.items():
        run = plan_by_id[run_id]
        path = checkpoint_path(checkpoint_dir, run_id)
        if valid_checkpoint_rows(path, run) is not None:
            continue
        expected = int(run.get("trace_count", 1) or 1)
        unique = {str(row.get("run_id", "")): row for row in rows}
        if len(unique) != expected:
            continue
        write_parent_checkpoint(
            checkpoint_dir,
            run,
            list(unique.values()),
            worker_id="legacy_import",
        )
        migrated += 1
    return migrated


def checkpoint_token_total(checkpoint_dir: Path) -> int:
    total = 0
    if not checkpoint_dir.exists():
        return total
    for path in checkpoint_dir.glob("rp_*.json"):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        total += sum(int(row.get("total_tokens", 0) or 0) for row in payload.get("rows", []))
    return total


def record_checkpoint_tokens(db_path: Path, run_id: str, tokens: int) -> int:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path, timeout=30) as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute(
            "CREATE TABLE IF NOT EXISTS checkpoint_tokens "
            "(run_id TEXT PRIMARY KEY, tokens INTEGER NOT NULL CHECK(tokens >= 0))"
        )
        connection.execute(
            "INSERT INTO checkpoint_tokens(run_id, tokens) VALUES (?, ?) "
            "ON CONFLICT(run_id) DO UPDATE SET tokens=excluded.tokens",
            (run_id, max(0, int(tokens))),
        )
        total = int(
            connection.execute(
                "SELECT COALESCE(SUM(tokens), 0) FROM checkpoint_tokens"
            ).fetchone()[0]
        )
        connection.commit()
    return total


def token_ledger_total(db_path: Path) -> int:
    if not db_path.exists():
        return 0
    with sqlite3.connect(db_path, timeout=30) as connection:
        try:
            return int(
                connection.execute(
                    "SELECT COALESCE(SUM(tokens), 0) FROM checkpoint_tokens"
                ).fetchone()[0]
            )
        except sqlite3.OperationalError:
            return 0


def sync_token_ledger(checkpoint_dir: Path, db_path: Path) -> int:
    total = 0
    if not checkpoint_dir.exists():
        return token_ledger_total(db_path)
    for path in checkpoint_dir.glob("rp_*.json"):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        run_id = str(payload.get("parent_run_id", ""))
        if not run_id:
            continue
        tokens = sum(int(row.get("total_tokens", 0) or 0) for row in payload.get("rows", []))
        total = record_checkpoint_tokens(db_path, run_id, tokens)
    return total


def merge_checkpoints(
    plan: dict[str, Any], checkpoint_dir: Path
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    result_ids: set[str] = set()
    missing: list[str] = []
    for run in plan["runs"]:
        run_id = str(run["run_id"])
        checkpoint_rows = valid_checkpoint_rows(
            checkpoint_path(checkpoint_dir, run_id), run
        )
        if checkpoint_rows is None:
            missing.append(run_id)
            continue
        checkpoint_rows = sorted(
            checkpoint_rows, key=lambda row: int(row.get("episode_index", 0) or 0)
        )
        for row in checkpoint_rows:
            result_id = str(row["run_id"])
            if result_id in result_ids:
                raise ValueError(f"duplicate result run_id: {result_id}")
            result_ids.add(result_id)
            rows.append(row)
    if missing:
        raise ValueError(f"missing or invalid parent checkpoints: {len(missing)}")
    expected_traces = int(plan.get("total_traces", 0) or 0)
    if len(rows) != expected_traces:
        raise ValueError(f"merged rows={len(rows)}, expected={expected_traces}")
    hashes = [str(row.get("provider_response_hash", "")) for row in rows]
    if any(not value for value in hashes) or len(hashes) != len(set(hashes)):
        raise ValueError("provider_response_hash values are missing or not unique")
    return rows


def write_canonical_results(
    rows: list[dict[str, Any]], jsonl_path: Path, csv_path: Path
) -> None:
    jsonl_path.parent.mkdir(parents=True, exist_ok=True)
    json_tmp = jsonl_path.with_name(f".{jsonl_path.name}.tmp")
    with json_tmp.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(json_tmp, jsonl_path)
    fields = sorted({field for row in rows for field in row})
    csv_tmp = csv_path.with_name(f".{csv_path.name}.tmp")
    with csv_tmp.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(csv_tmp, csv_path)
