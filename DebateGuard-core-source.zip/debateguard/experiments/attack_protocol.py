from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


ALLOWED_TERMINAL_FAMILIES = {
    "active_memory_regression",
    "evolution_shift",
    "final_adoption",
}


@dataclass(frozen=True)
class AttackBinding:
    benchmark_stratum: str
    expected_terminal_family: str
    attacks: list[dict[str, Any]]
    rationale: str


@dataclass(frozen=True)
class AttackProtocol:
    version: str
    protocol_hash: str
    bindings: dict[str, AttackBinding]


def canonical_protocol_hash(payload: dict[str, Any]) -> str:
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def load_attack_protocol(path: str | Path) -> AttackProtocol:
    source = Path(path)
    payload = yaml.safe_load(source.read_text(encoding="utf-8")) or {}
    version = str(payload.get("attack_protocol_version", "")).strip()
    if not version:
        raise ValueError(f"{source}: missing attack_protocol_version")
    raw_bindings = payload.get("bindings")
    if not isinstance(raw_bindings, dict) or not raw_bindings:
        raise ValueError(f"{source}: bindings must be a non-empty mapping")

    bindings: dict[str, AttackBinding] = {}
    for stratum, raw in raw_bindings.items():
        if not isinstance(raw, dict):
            raise ValueError(f"{source}: binding {stratum} must be a mapping")
        terminal = str(raw.get("expected_terminal_family", "")).strip()
        if terminal not in ALLOWED_TERMINAL_FAMILIES:
            raise ValueError(
                f"{source}: binding {stratum} has invalid terminal family {terminal!r}"
            )
        attacks = raw.get("attacks")
        if not isinstance(attacks, list) or not attacks:
            raise ValueError(f"{source}: binding {stratum} must define attacks")
        normalized_attacks: list[dict[str, Any]] = []
        for index, attack in enumerate(attacks):
            if not isinstance(attack, dict) or not attack.get("attack_type"):
                raise ValueError(
                    f"{source}: binding {stratum} attack {index} lacks attack_type"
                )
            normalized_attacks.append(dict(attack))
        bindings[str(stratum)] = AttackBinding(
            benchmark_stratum=str(stratum),
            expected_terminal_family=terminal,
            attacks=normalized_attacks,
            rationale=str(raw.get("rationale", "")).strip(),
        )
    return AttackProtocol(
        version=version,
        protocol_hash=canonical_protocol_hash(payload),
        bindings=bindings,
    )


def protocol_binding_for_task(
    protocol: AttackProtocol,
    task: dict[str, Any],
) -> AttackBinding:
    metadata = task.get("metadata") if isinstance(task.get("metadata"), dict) else {}
    stratum = str(
        task.get("benchmark_stratum")
        or metadata.get("benchmark_stratum")
        or ""
    )
    if stratum not in protocol.bindings:
        raise ValueError(
            f"Task {task.get('task_id')} stratum {stratum!r} is not bound by "
            f"{protocol.version}"
        )
    binding = protocol.bindings[stratum]
    declared_terminal = str(
        task.get("terminal_risk_family")
        or metadata.get("terminal_risk_family")
        or ""
    )
    if declared_terminal and declared_terminal != binding.expected_terminal_family:
        raise ValueError(
            f"Task {task.get('task_id')} terminal family mismatch: "
            f"task={declared_terminal} protocol={binding.expected_terminal_family}"
        )
    return binding
