from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd

from debateguard.artifacts import append_trace_manifest
from debateguard.config import expand_matrix_config, load_config
from debateguard.debate import DebateEngine
from debateguard.metrics import trace_to_result_row
from debateguard.schemas import DebateTrace
from debateguard.tracing import save_trace, trace_hash


@dataclass(frozen=True)
class ExperimentRunResult:
    result_path: Path
    run_dir: Path
    manifest_path: Path
    trace_paths: list[Path]
    traces: list[DebateTrace]
    rows: list[dict[str, object]]

    def summary(self, preview_limit: int = 20) -> dict[str, object]:
        return {
            "results": str(self.result_path),
            "num_traces": len(self.traces),
            "traces_preview": [str(path) for path in self.trace_paths[:preview_limit]],
            "traces_omitted": max(0, len(self.trace_paths) - preview_limit),
        }


def run_experiment_file(config_path: str | Path, run_id: str | None = None) -> ExperimentRunResult:
    return run_experiment_config(load_config(config_path), run_id=run_id)


def run_experiment_config(config: dict[str, Any], run_id: str | None = None) -> ExperimentRunResult:
    output_dir = Path(os.environ.get("DEBATEGUARD_TRACE_DIR") or config.get("output", {}).get("trace_dir", "data/traces"))
    result_dir = Path(config.get("output", {}).get("result_dir", "data/results"))
    result_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = Path(os.environ.get("DEBATEGUARD_TRACE_MANIFEST") or config.get("output", {}).get("manifest_jsonl", output_dir / "manifest.jsonl"))
    manifest_path.parent.mkdir(parents=True, exist_ok=True)

    traces: list[DebateTrace] = []
    rows: list[dict[str, object]] = []
    trace_paths: list[Path] = []
    for expanded in expand_matrix_config(config, run_id=run_id):
        expanded.setdefault("run_slug", _run_slug(expanded))
        engine = DebateEngine(expanded)
        for trace in engine.run():
            trace.metadata["run_slug"] = expanded["run_slug"]
            trace.metadata["trace_hash"] = trace_hash(trace)
            path = save_trace(trace, output_dir)
            traces.append(trace)
            trace_paths.append(path)
            rows.append(trace_to_result_row(trace))

    experiment_name = str(config.get("experiment_name", "experiment"))
    result_path = result_dir / f"{experiment_name}.csv"
    result_df = pd.DataFrame(rows)
    result_df.to_csv(result_path, index=False)
    append_trace_manifest(manifest_path, traces, trace_paths)

    run_dir = result_dir / f"{experiment_name}_run"
    run_dir.mkdir(parents=True, exist_ok=True)
    result_df.to_csv(run_dir / "metrics.csv", index=False)
    (run_dir / "config.json").write_text(json.dumps(config, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8")

    return ExperimentRunResult(
        result_path=result_path,
        run_dir=run_dir,
        manifest_path=manifest_path,
        trace_paths=trace_paths,
        traces=traces,
        rows=rows,
    )


def _run_slug(config: dict[str, Any]) -> str:
    return "_".join(
        str(part)
        for part in [
            config.get("base_experiment_name", config.get("experiment_name", "rq")),
            config.get("model", {}).get("model_alias") or config.get("model", {}).get("model") or config.get("model", {}).get("provider", "mock"),
            config.get("debate", {}).get("topology", "topology"),
            config.get("attack_type", "mixed"),
            "evolution" if config.get("evolution") else "static",
            config.get("defense", {}).get("name", "none"),
            f"seed{config.get('seed', 42)}",
        ]
    )
