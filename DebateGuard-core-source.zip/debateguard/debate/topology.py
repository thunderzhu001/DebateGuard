from __future__ import annotations

from debateguard.schemas import AgentState, DebateMessage, DebateTrace


class DebateTopology:
    VALID = {
        "independent",
        "fully_connected",
        "chain",
        "star_judge",
        "critic_defender",
        "hierarchical",
        "rotating_judge",
    }

    def __init__(self, name: str) -> None:
        if name not in self.VALID:
            raise ValueError(f"Unknown topology '{name}'. Valid topologies: {sorted(self.VALID)}")
        self.name = name

    def schedule(self, agents: list[AgentState], round_id: int) -> list[tuple[str, list[str]]]:
        ids = [agent.agent_id for agent in agents]
        judges = [agent.agent_id for agent in agents if agent.role == "judge"]
        judge_id = judges[(round_id - 1) % len(judges)] if judges else ids[-1]

        if self.name == "independent":
            return [(agent_id, [judge_id]) for agent_id in ids if agent_id != judge_id] + [(judge_id, [])]
        if self.name == "fully_connected":
            return [(agent_id, [other for other in ids if other != agent_id]) for agent_id in ids]
        if self.name == "chain":
            pairs: list[tuple[str, list[str]]] = []
            for index, agent_id in enumerate(ids):
                receiver = [ids[index + 1]] if index + 1 < len(ids) else []
                pairs.append((agent_id, receiver))
            return pairs
        if self.name == "star_judge":
            return [(agent_id, [judge_id]) for agent_id in ids if agent_id != judge_id] + [(judge_id, ids)]
        if self.name == "critic_defender":
            ordered_roles = ["proposer", "critic", "defender", "verifier", "judge", "memory_manager", "summarizer", "adversary"]
            ordered = sorted(agents, key=lambda agent: ordered_roles.index(agent.role) if agent.role in ordered_roles else 99)
            return [(agent.agent_id, [judge_id]) for agent in ordered]
        if self.name == "hierarchical":
            summarizers = [agent.agent_id for agent in agents if agent.role == "summarizer"]
            summary_id = summarizers[0] if summarizers else judge_id
            return [
                (agent_id, [summary_id] if agent_id not in {summary_id, judge_id} else [judge_id])
                for agent_id in ids
            ]
        if self.name == "rotating_judge":
            return [(agent_id, [judge_id]) for agent_id in ids if agent_id != judge_id] + [(judge_id, ids)]
        raise AssertionError("unreachable")

    def get_speakers(self, round_id: int, agents: list[AgentState]) -> list[str]:
        return [sender_id for sender_id, _ in self.schedule(agents, round_id)]

    def get_receivers(self, sender_id: str, round_id: int, agents: list[AgentState]) -> list[str]:
        for scheduled_sender, receiver_ids in self.schedule(agents, round_id):
            if scheduled_sender == sender_id:
                return receiver_ids
        return []

    def get_visible_messages(self, agent_id: str, round_id: int, trace: DebateTrace) -> list[DebateMessage]:
        role_by_id = {agent.agent_id: agent.role for agent in trace.agents}
        previous = [message for message in trace.messages if message.round_id < round_id]
        same_round_prior = [message for message in trace.messages if message.round_id == round_id]
        if self.name == "independent":
            return previous if role_by_id.get(agent_id) == "judge" else []
        if self.name == "chain":
            ordered = [agent.agent_id for agent in trace.agents]
            index = ordered.index(agent_id) if agent_id in ordered else -1
            if index <= 0:
                return []
            predecessor = ordered[index - 1]
            return [message for message in same_round_prior + previous if message.sender_id == predecessor][-1:]
        if self.name == "star_judge":
            if role_by_id.get(agent_id) == "judge":
                return previous + same_round_prior
            return [message for message in previous if role_by_id.get(message.sender_id) == "judge"]
        if self.name == "critic_defender":
            return previous + same_round_prior[-2:]
        if self.name == "hierarchical":
            if role_by_id.get(agent_id) == "judge":
                return [message for message in previous + same_round_prior if role_by_id.get(message.sender_id) == "summarizer"]
            if role_by_id.get(agent_id) == "summarizer":
                return previous + same_round_prior
            return previous
        return previous

    def visible_messages(self, sender_id: str, all_message_ids: list[str], round_messages: list[str]) -> list[str]:
        if self.name == "independent":
            return []
        if self.name == "chain":
            return round_messages[-1:]
        return all_message_ids
