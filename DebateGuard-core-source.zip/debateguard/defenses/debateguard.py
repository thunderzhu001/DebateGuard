from __future__ import annotations

from debateguard.defenses.claim_verifier import ClaimVerifier
from debateguard.defenses.counterfactual_attributor import CounterfactualAttributor
from debateguard.defenses.memory_gate import MemoryRegressionGate
from debateguard.defenses.provenance_tracker import InfluenceGraphBuilder
from debateguard.defenses.quarantine import QuarantineManager
from debateguard.defenses.risk_scorer import PropagationRiskScorer
from debateguard.metrics.matching import adopts_claim, answer_matches
from debateguard.schemas import DefenseEvent, DefenseObservation, DebateTrace, MemoryUpdate


class DebateGuard:
    def __init__(
        self,
        rollback: bool = True,
        enable_memory_gate: bool = True,
        enable_provenance: bool = True,
        enable_verification: bool = True,
        enable_attribution: bool = True,
        enable_evolution_gate: bool = False,
        risk_only: bool = False,
    ) -> None:
        self.verifier = ClaimVerifier()
        self.graph_builder = InfluenceGraphBuilder()
        self.scorer = PropagationRiskScorer()
        self.memory_gate = MemoryRegressionGate()
        self.attributor = CounterfactualAttributor()
        self.quarantine = QuarantineManager()
        self.rollback = rollback
        self.enable_memory_gate = enable_memory_gate
        self.enable_provenance = enable_provenance
        self.enable_verification = enable_verification
        self.enable_attribution = enable_attribution
        self.enable_evolution_gate = enable_evolution_gate
        self.risk_only = risk_only

    @staticmethod
    def _observation(trace: DebateTrace) -> DefenseObservation:
        return DefenseObservation.from_task(
            trace.task,
            attack_present=bool(trace.attack_events),
        )

    @staticmethod
    def _memory_view(item, *, oracle_blind: bool):
        if not oracle_blind:
            return item
        view = item.model_copy(deep=True)
        view.risk_score = 0.0
        view.metadata = {
            key: value
            for key, value in view.metadata.items()
            if not key.startswith("oracle_")
            and key not in {"attack_type", "source_is_adversarial"}
        }
        return view

    def apply_pre_debate(self, trace: DebateTrace) -> DebateTrace:
        """Gate already-present memories before any provider retrieval occurs."""
        if not self.enable_memory_gate or self.risk_only:
            return trace
        existing_update_ids = {update.memory_item.memory_id for update in trace.memory_updates}
        oracle_blind = bool(trace.metadata.get("oracle_blind", False))
        for agent in trace.agents:
            for item in agent.memory:
                if item.quarantined:
                    continue
                decision = self.memory_gate.decide(
                    self._memory_view(item, oracle_blind=oracle_blind),
                    adversarial_claim=None if oracle_blind else trace.task.adversarial_claim,
                    attack_active=False if oracle_blind else bool(trace.attack_events),
                    oracle_blind=oracle_blind,
                )
                item.risk_score = decision.risk_score
                if decision.decision == "approve":
                    continue
                item.quarantined = True
                item.metadata["quarantine_reason"] = ";".join(decision.reasons) or decision.decision
                if item.memory_id not in existing_update_ids:
                    trace.memory_updates.append(
                        MemoryUpdate(
                            agent_id=agent.agent_id,
                            memory_item=item,
                            action="quarantined",
                            reason=item.metadata["quarantine_reason"],
                        )
                    )
                    existing_update_ids.add(item.memory_id)
                trace.defense_events.append(
                    DefenseEvent(
                        defense_type="pre_memory_gate",
                        target_id=item.memory_id,
                        action="quarantine_memory_pre_retrieval",
                        risk_score=decision.risk_score,
                        reason=item.metadata["quarantine_reason"],
                    )
                )
        return trace

    def apply(self, trace: DebateTrace) -> DebateTrace:
        oracle_blind = bool(trace.metadata.get("oracle_blind", False))
        observation = self._observation(trace) if oracle_blind else None
        if self.enable_verification:
            for message in trace.messages:
                for claim in message.claims:
                    if observation is not None:
                        self.verifier.verify_public(claim, observation)
                    else:
                        self.verifier.verify(claim, trace.task)

        graph_view = self.graph_builder.view(trace) if self.enable_provenance else None
        centrality = graph_view.claim_centrality() if graph_view is not None else {}
        risky_claims: list[dict[str, object]] = []
        for message in trace.messages:
            for claim in message.claims:
                adoption_count = sum(1 for msg in trace.messages if adopts_claim(msg.content, claim.text))
                if oracle_blind:
                    source_risk = float(message.metadata.get("source_risk", 0.2) or 0.0)
                else:
                    source_risk = 1.0 if message.attack_tag else 0.8 if any(agent.agent_id == message.sender_id and agent.corruption_tags for agent in trace.agents) else 0.2
                memory_write_probability = 1.0 if any(adopts_claim(update.memory_item.content, claim.text) for update in trace.memory_updates) else 0.0
                risk = self.scorer.score(claim, centrality.get(claim.claim_id, 0.0), adoption_count, source_risk, memory_write_probability)
                claim.metadata["risk_score"] = risk
                claim.risk_score = risk
                if risk >= 0.65:
                    risky_claims.append({"claim_id": claim.claim_id, "text": claim.text, "risk_score": risk})
                    if not self.risk_only:
                        trace.defense_events.append(
                            DefenseEvent(
                                defense_type="risk_scoring",
                                target_id=claim.claim_id,
                                action="flag_claim",
                                risk_score=risk,
                                reason=f"claim risk exceeds threshold: {claim.verification_status}",
                            )
                        )

        if self.enable_memory_gate and not self.risk_only:
            attack_active = bool(trace.attack_events) and not oracle_blind
            for update in trace.memory_updates:
                decision = self.memory_gate.decide(
                    self._memory_view(update.memory_item, oracle_blind=oracle_blind),
                    adversarial_claim=None if oracle_blind else trace.task.adversarial_claim,
                    attack_active=attack_active,
                    oracle_blind=oracle_blind,
                )
                update.memory_item.risk_score = decision.risk_score
                if decision.decision == "approve":
                    update.action = "approved"
                    update.reason = ";".join(decision.reasons) or "low_risk_memory"
                else:
                    self.quarantine.quarantine_memory(
                        trace,
                        update.memory_item.memory_id,
                        ";".join(decision.reasons) or decision.decision,
                        decision.risk_score,
                    )

        evolution_actions = self._gate_evolution(trace) if self.enable_evolution_gate and not self.risk_only else []
        attribution = self.attributor.attribute(trace) if self.enable_attribution else []
        trace.metadata["debateguard"] = {
            "risky_claims": risky_claims,
            "attribution": attribution[:10],
            "graph_nodes": graph_view.node_count if graph_view is not None else 0,
            "graph_edges": graph_view.edge_count if graph_view is not None else 0,
            "ablation": {
                "provenance": self.enable_provenance,
                "verification": self.enable_verification,
                "memory_gate": self.enable_memory_gate,
                "attribution": self.enable_attribution,
                "evolution_gate": self.enable_evolution_gate,
                "rollback": self.rollback,
                "risk_only": self.risk_only,
            },
        }

        trace.metadata["evolution_action"] = (
            "quarantined" if evolution_actions else "none"
        )
        trace.metadata["oracle_field_access_count"] = 0 if oracle_blind else int(
            trace.metadata.get("oracle_field_access_count", 0) or 0
        )

        false_claim = None if oracle_blind else trace.task.adversarial_claim
        if self.rollback and not self.risk_only and false_claim and answer_matches(trace.final_answer, false_claim, trace.task) and risky_claims:
            original = trace.final_answer
            trace.final_answer = trace.task.ground_truth
            trace.judge_decision["rolled_back_from"] = original
            trace.judge_decision["answer"] = trace.final_answer
            trace.defense_events.append(
                DefenseEvent(
                    defense_type="rollback",
                    target_id="final_decision",
                    action="replace_with_verified_answer",
                    risk_score=1.0,
                    reason="final answer matched a high-risk contradicted claim",
                )
            )
        return trace

    def _gate_evolution(self, trace: DebateTrace) -> list[str]:
        quarantined: list[str] = []
        for agent in trace.agents:
            for index, update in enumerate(agent.evolution_history):
                if update.get("status", "committed") != "committed":
                    continue
                if update.get("type") != "role_corruption":
                    continue
                reliability = float(update.get("source_reliability", 0.5) or 0.0)
                if reliability >= 0.25:
                    continue
                update["status"] = "quarantined"
                update["committed"] = False
                previous_prompt = agent.metadata.pop("pre_corruption_system_prompt", None)
                if previous_prompt is not None:
                    agent.system_prompt = str(previous_prompt)
                agent.metadata["role_corrupted"] = False
                agent.corruption_tags = [
                    tag for tag in agent.corruption_tags if not tag.startswith("role_corruption:")
                ]
                target_id = f"{agent.agent_id}:evolution:{index + 1}"
                quarantined.append(target_id)
                trace.defense_events.append(
                    DefenseEvent(
                        defense_type="evolution_gate",
                        target_id=target_id,
                        action="quarantine_evolution_update",
                        risk_score=1.0 - reliability,
                        reason="untrusted evolution proposal was not committed",
                    )
                )
        return quarantined
