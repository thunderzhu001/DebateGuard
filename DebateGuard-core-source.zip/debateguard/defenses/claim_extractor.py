from __future__ import annotations

import re

from debateguard.metrics.matching import mentions_claim
from debateguard.schemas import Claim, DebateMessage, DebateTask


class RuleClaimExtractor:
    def extract(self, message: DebateMessage, task: DebateTask) -> list[Claim]:
        claims: list[Claim] = []
        candidates: list[tuple[str, str]] = []
        if task.ground_truth and mentions_claim(message.content, task.ground_truth):
            candidates.append((task.ground_truth, "factual"))
        if task.adversarial_claim and mentions_claim(message.content, task.adversarial_claim):
            candidates.append((task.adversarial_claim, "factual"))

        for sentence in re.split(r"(?<=[.!?])\s+", message.content.strip()):
            clean = sentence.strip()
            if not clean or len(clean.split()) < 4:
                continue
            if clean not in {text for text, _ in candidates}:
                candidates.append((clean[:300], "reasoning"))

        seen: set[str] = set()
        for text, claim_type in candidates[:6]:
            if text in seen:
                continue
            seen.add(text)
            safety_relevance = 0.9 if task.adversarial_claim and mentions_claim(text, task.adversarial_claim) else 0.55
            claims.append(
                Claim(
                    text=text,
                    claim_type=claim_type,
                    source_message_id=message.message_id,
                    source_agent_id=message.sender_id,
                    safety_relevance=safety_relevance,
                    uncertainty=0.35 if task.ground_truth and mentions_claim(text, task.ground_truth) else 0.75,
                    metadata={"source_role": message.metadata.get("role")},
                )
            )
        return claims
