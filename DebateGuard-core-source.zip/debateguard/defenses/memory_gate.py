from __future__ import annotations

from pydantic import BaseModel

from debateguard.metrics.matching import adopts_claim
from debateguard.schemas import MemoryItem


class MemoryGateDecision(BaseModel):
    memory_item_id: str
    decision: str
    reasons: list[str]
    risk_score: float


class MemoryRegressionGate:
    def decide(
        self,
        item: MemoryItem,
        *,
        adversarial_claim: str | None = None,
        attack_active: bool = False,
        oracle_blind: bool = False,
    ) -> MemoryGateDecision:
        reasons: list[str] = []
        risk = item.risk_score
        verification_status = str(item.metadata.get("verification_status", "supported" if item.verified else "unverified"))
        source_role = str(item.metadata.get("source_role", ""))
        claim_type = str(item.metadata.get("claim_type", "factual"))
        if not oracle_blind and adversarial_claim and adopts_claim(item.content, adversarial_claim):
            reasons.append("contains_adversarial_claim")
            risk = max(risk, 0.95)
        if verification_status == "contradicted":
            reasons.append("contradicted_claim")
            risk = max(risk, 0.98)
        if claim_type == "factual" and verification_status != "supported":
            reasons.append("unverified_factual_memory")
            risk = max(risk, 0.75)
        if source_role == "adversary" or (
            not oracle_blind and item.metadata.get("source_is_adversarial")
        ):
            reasons.append("adversarial_source")
            risk = max(risk, 0.8)
        if item.metadata.get("changes_safety_policy") and verification_status != "supported":
            reasons.append("unverified_safety_policy_change")
            risk = max(risk, 0.85)
        if not item.verified:
            reasons.append("unverified_memory")
            risk = max(risk, 0.6)
        source_reliability = float(item.metadata.get("source_reliability", 0.5) or 0.0)
        if oracle_blind and source_reliability < 0.25:
            reasons.append("low_source_reliability")
            risk = max(risk, 0.85)
        if oracle_blind and not item.source_message_ids and not item.source_claim_ids:
            reasons.append("missing_source_lineage")
            risk = max(risk, 0.7)
        if attack_active and not oracle_blind:
            reasons.append("introduced_after_attack_event")
            risk = max(risk, 0.7)
        if risk >= 0.85:
            decision = "quarantine"
        elif risk >= 0.65:
            decision = "quarantine" if "unverified_factual_memory" in reasons else "reject"
        else:
            decision = "approve"
        return MemoryGateDecision(memory_item_id=item.memory_id, decision=decision, reasons=reasons, risk_score=round(risk, 4))


def next_memory_gate_state(current_state: str, decision: str, *, rollback: bool = False) -> str:
    """State transition used by the formal memory-gate proof."""
    state = current_state or "candidate"
    if rollback:
        return "rolled_back"
    if decision == "approve":
        return "accepted"
    if decision == "quarantine":
        return "quarantined"
    if decision == "reject":
        return "disabled"
    return state
