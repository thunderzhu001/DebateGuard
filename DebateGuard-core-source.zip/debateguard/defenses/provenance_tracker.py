from __future__ import annotations

from dataclasses import dataclass

import networkx as nx

from debateguard.schemas import DebateTrace
from debateguard.metrics.matching import adopts_claim, mentions_claim


@dataclass(frozen=True)
class ClaimInfluenceGraph:
    """Typed query view over the trace-induced claim influence graph."""

    graph: nx.MultiDiGraph

    @property
    def node_count(self) -> int:
        return self.graph.number_of_nodes()

    @property
    def edge_count(self) -> int:
        return self.graph.number_of_edges()

    def claim_centrality(self) -> dict[str, float]:
        if self.graph.number_of_nodes() == 0:
            return {}
        simple = nx.DiGraph()
        for src, dst, data in self.graph.edges(data=True):
            simple.add_edge(src, dst, weight=data.get("weight", 1.0))
        return nx.degree_centrality(simple)

    def adoption_count(self, claim_id: str) -> int:
        return sum(1 for _, _, data in self.graph.out_edges(claim_id, data=True) if data.get("edge_type") == "adopts")

    def propagation_depth(self, claim_id: str) -> int:
        simple = self._simple_graph()
        if claim_id not in simple:
            return 0
        lengths = nx.single_source_shortest_path_length(simple, claim_id)
        return max(lengths.values(), default=0)

    def influence_centrality(self, claim_id: str) -> float:
        return self.claim_centrality().get(claim_id, 0.0)

    def paths_to_final_decision(self, claim_id: str) -> list[list[str]]:
        return self._paths(claim_id, "final_decision")

    def paths_to_memory(self, claim_id: str) -> list[list[str]]:
        memory_nodes = [node for node, data in self.graph.nodes(data=True) if data.get("node_type") == "memory"]
        paths: list[list[str]] = []
        for node in memory_nodes:
            paths.extend(self._paths(claim_id, node))
        return paths

    def reachable_terminal_count(self, source: str) -> int:
        if source not in self.graph:
            return 0
        visited: set[str] = set()
        stack = [source]
        while stack:
            node = stack.pop()
            for successor in self.graph.successors(node):
                if successor in visited:
                    continue
                visited.add(successor)
                stack.append(successor)
        count = int("final_decision" in visited)
        count += sum(1 for node in visited if self.graph.nodes[node].get("node_type") == "memory")
        return count

    def to_json(self) -> dict[str, object]:
        return {
            "nodes": [{"id": node, **data} for node, data in self.graph.nodes(data=True)],
            "edges": [{"source": src, "target": dst, **data} for src, dst, data in self.graph.edges(data=True)],
        }

    def _paths(self, source: str, target: str) -> list[list[str]]:
        simple = self._simple_graph()
        if source not in simple or target not in simple:
            return []
        return [path for path in nx.all_simple_paths(simple, source, target, cutoff=8)]

    def _simple_graph(self) -> nx.DiGraph:
        simple = nx.DiGraph()
        simple.add_edges_from((src, dst) for src, dst in self.graph.edges())
        return simple


class InfluenceGraphBuilder:
    def view(self, trace: DebateTrace) -> ClaimInfluenceGraph:
        return ClaimInfluenceGraph(self.build(trace))

    def build(self, trace: DebateTrace) -> nx.MultiDiGraph:
        graph = nx.MultiDiGraph(trace_id=trace.trace_id)
        for agent in trace.agents:
            graph.add_node(agent.agent_id, node_type="agent", role=agent.role)
        for message in trace.messages:
            graph.add_node(
                message.message_id,
                node_type="message",
                round_id=message.round_id,
                attack_tag=message.attack_tag,
                text=message.content,
                risk_score=0.0,
                agent_id=message.sender_id,
            )
            graph.add_edge(message.sender_id, message.message_id, edge_type="sent", weight=1.0)
            for receiver_id in message.receiver_ids:
                graph.add_edge(message.message_id, receiver_id, edge_type="received_by", weight=0.5)
            for parent_id in message.parent_message_ids:
                graph.add_edge(parent_id, message.message_id, edge_type="influences", weight=0.35)
            for claim in message.claims:
                graph.add_node(
                    claim.claim_id,
                    node_type="claim",
                    status=claim.verification_status,
                    text=claim.text,
                    risk_score=claim.risk_score,
                    round_id=message.round_id,
                    agent_id=message.sender_id,
                )
                graph.add_edge(message.message_id, claim.claim_id, edge_type="mentions", weight=0.8)
                for later in trace.messages:
                    if later.message_id != message.message_id and later.round_id >= message.round_id and adopts_claim(later.content, claim.text):
                        graph.add_edge(claim.claim_id, later.message_id, edge_type="adopts", weight=0.7)
        graph.add_node("final_decision", node_type="decision", answer=trace.final_answer)
        for message in trace.messages:
            if trace.final_answer and mentions_claim(message.content, trace.final_answer):
                graph.add_edge(message.message_id, "final_decision", edge_type="influences_decision", weight=0.8)
            for claim in message.claims:
                if trace.final_answer and adopts_claim(trace.final_answer, claim.text):
                    graph.add_edge(claim.claim_id, "final_decision", edge_type="accepted_in_decision", weight=0.9)
        for update in trace.memory_updates:
            memory_id = update.memory_item.memory_id
            graph.add_node(
                memory_id,
                node_type="memory",
                quarantined=update.memory_item.quarantined,
                text=update.memory_item.content,
                risk_score=update.memory_item.risk_score,
            )
            if update.memory_item.source_message_id:
                graph.add_edge(update.memory_item.source_message_id, memory_id, edge_type="writes_to_memory", weight=1.0)
            for claim_id in update.memory_item.source_claim_ids:
                graph.add_edge(claim_id, memory_id, edge_type="writes", weight=1.0)
        return graph

    def claim_centrality(self, graph: nx.MultiDiGraph) -> dict[str, float]:
        return ClaimInfluenceGraph(graph).claim_centrality()

    def get_claim_adoption_count(self, graph: nx.MultiDiGraph, claim_id: str) -> int:
        return ClaimInfluenceGraph(graph).adoption_count(claim_id)

    def get_claim_propagation_depth(self, graph: nx.MultiDiGraph, claim_id: str) -> int:
        return ClaimInfluenceGraph(graph).propagation_depth(claim_id)

    def get_claim_influence_centrality(self, graph: nx.MultiDiGraph, claim_id: str) -> float:
        return ClaimInfluenceGraph(graph).influence_centrality(claim_id)

    def get_paths_to_final_decision(self, graph: nx.MultiDiGraph, claim_id: str) -> list[list[str]]:
        return ClaimInfluenceGraph(graph).paths_to_final_decision(claim_id)

    def get_paths_to_memory(self, graph: nx.MultiDiGraph, claim_id: str) -> list[list[str]]:
        return ClaimInfluenceGraph(graph).paths_to_memory(claim_id)

    def to_json(self, graph: nx.MultiDiGraph) -> dict[str, object]:
        return ClaimInfluenceGraph(graph).to_json()

    @staticmethod
    def _paths(graph: nx.MultiDiGraph, source: str, target: str) -> list[list[str]]:
        return ClaimInfluenceGraph(graph)._paths(source, target)
