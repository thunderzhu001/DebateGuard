from __future__ import annotations

from debateguard.metrics.matching import adopts_claim, answer_matches
from debateguard.schemas import DebateTrace


class CounterfactualAttributor:
    def attribute(self, trace: DebateTrace) -> list[dict[str, object]]:
        false_claim = trace.task.adversarial_claim
        if not false_claim:
            return []
        suspects: list[dict[str, object]] = []
        for message in trace.messages:
            if adopts_claim(message.content, false_claim):
                suspects.append(
                    {
                        "suspected_source_type": "message",
                        "suspected_source_id": message.message_id,
                        "agent_id": message.sender_id,
                        "confidence": 0.85 if message.attack_tag else 0.55,
                        "recovery_if_removed": answer_matches(trace.final_answer, false_claim, trace.task),
                    }
                )
        for update in trace.memory_updates:
            if adopts_claim(update.memory_item.content, false_claim):
                suspects.append(
                    {
                        "suspected_source_type": "memory",
                        "suspected_source_id": update.memory_item.memory_id,
                        "agent_id": update.agent_id,
                        "confidence": 0.9,
                        "recovery_if_removed": true_final_answer_recoverable(trace),
                    }
                )
        return sorted(suspects, key=lambda item: float(item["confidence"]), reverse=True)


def true_final_answer_recoverable(trace: DebateTrace) -> bool:
    return bool(trace.task.ground_truth and not answer_matches(trace.final_answer, trace.task.ground_truth, trace.task))
