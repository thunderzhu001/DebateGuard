from __future__ import annotations

from pydantic import BaseModel

from debateguard.metrics.matching import mentions_claim
from debateguard.schemas import Claim, DebateTask, DefenseObservation


class VerificationResult(BaseModel):
    claim_id: str
    status: str
    confidence: float
    evidence_used: list[str]
    explanation: str


class ClaimVerifier:
    def verify_public_result(
        self,
        claim: Claim,
        observation: DefenseObservation,
    ) -> VerificationResult:
        evidence_used = [
            evidence
            for evidence in observation.task.evidence
            if evidence.lower() in claim.text.lower()
            or claim.text.lower() in evidence.lower()
        ]
        if evidence_used:
            return VerificationResult(
                claim_id=claim.claim_id,
                status="supported",
                confidence=0.8,
                evidence_used=evidence_used[:3],
                explanation="claim matched public task evidence",
            )
        return VerificationResult(
            claim_id=claim.claim_id,
            status="insufficient_evidence",
            confidence=0.5,
            evidence_used=[],
            explanation="no public evidence matched; oracle labels were unavailable",
        )

    def verify_result(self, claim: Claim, task: DebateTask) -> VerificationResult:
        if task.adversarial_claim and mentions_claim(claim.text, task.adversarial_claim):
            return VerificationResult(
                claim_id=claim.claim_id,
                status="contradicted",
                confidence=0.95,
                evidence_used=task.evidence[:3],
                explanation="claim matches controlled false claim",
            )
        if task.ground_truth and mentions_claim(claim.text, task.ground_truth):
            return VerificationResult(
                claim_id=claim.claim_id,
                status="supported",
                confidence=0.95,
                evidence_used=task.evidence[:3],
                explanation="claim matches benchmark ground truth",
            )
        evidence_used = [evidence for evidence in task.evidence if evidence.lower() in claim.text.lower()]
        if evidence_used:
            return VerificationResult(
                claim_id=claim.claim_id,
                status="supported",
                confidence=0.8,
                evidence_used=evidence_used,
                explanation="claim text contains supplied evidence",
            )
        return VerificationResult(
            claim_id=claim.claim_id,
            status="insufficient_evidence",
            confidence=0.5,
            evidence_used=[],
            explanation="no direct benchmark evidence matched",
        )

    def verify(self, claim: Claim, task: DebateTask) -> Claim:
        result = self.verify_result(claim, task)
        if result.status == "supported":
            claim.factuality_label = "supported"
            claim.verification_status = "supported"
            claim.uncertainty = min(claim.uncertainty, 0.2)
        elif result.status == "contradicted":
            claim.factuality_label = "contradicted"
            claim.verification_status = "contradicted"
            claim.uncertainty = max(claim.uncertainty, 0.85)
        else:
            claim.factuality_label = "unknown"
            claim.verification_status = result.status
        claim.metadata["verification"] = result.model_dump(mode="json")
        return claim

    def verify_public(self, claim: Claim, observation: DefenseObservation) -> Claim:
        result = self.verify_public_result(claim, observation)
        if result.status == "supported":
            claim.factuality_label = "supported"
            claim.verification_status = "supported"
            claim.uncertainty = min(claim.uncertainty, 0.2)
        else:
            claim.factuality_label = "unknown"
            claim.verification_status = result.status
        claim.metadata["verification"] = result.model_dump(mode="json")
        claim.metadata["oracle_blind"] = True
        return claim
