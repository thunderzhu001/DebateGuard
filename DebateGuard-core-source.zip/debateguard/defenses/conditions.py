from __future__ import annotations

from typing import Any

from debateguard.defenses.debateguard import DebateGuard
from debateguard.metrics.matching import adopts_claim, answer_matches
from debateguard.schemas import DebateTrace, DefenseEvent


class DefenseConditionRunner:
    """Apply one configured Defense Condition to a DebateTrace."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self.config = config or {}
        self.enabled = bool(self.config.get("enabled", False))
        self.name = self.config.get("name") or ("full_debateguard" if self.enabled else "none")
        self.full_debateguard = self._guard_from_config(self.config)

    def apply(self, trace: DebateTrace) -> DebateTrace:
        if not self.enabled or self.name in {"none", "no_defense", "majority_voting"}:
            return trace
        if self.name == "confidence_filtering":
            return self._confidence_filtering(trace)
        if self.name in {"independent_verifier", "argus_like"}:
            return self._verifier_baseline(trace, self.name)
        if self.name == "memory_gate_only":
            return DebateGuard(rollback=False, enable_memory_gate=True, enable_provenance=False, enable_verification=False, enable_attribution=False, enable_evolution_gate=False).apply(trace)
        if self.name == "debateguard_no_provenance":
            return DebateGuard(rollback=True, enable_memory_gate=True, enable_provenance=False, enable_verification=True, enable_attribution=True).apply(trace)
        if self.name == "debateguard_no_verification":
            return DebateGuard(rollback=True, enable_memory_gate=True, enable_provenance=True, enable_verification=False, enable_attribution=True).apply(trace)
        if self.name == "debateguard_no_attribution":
            return DebateGuard(rollback=True, enable_memory_gate=True, enable_provenance=True, enable_verification=True, enable_attribution=False).apply(trace)
        if self.name == "debateguard_no_rollback":
            return DebateGuard(rollback=False, enable_memory_gate=True, enable_provenance=True, enable_verification=True, enable_attribution=True).apply(trace)
        if self.name == "debateguard_no_evolution_gate":
            return DebateGuard(rollback=True, enable_memory_gate=True, enable_provenance=True, enable_verification=True, enable_attribution=True, enable_evolution_gate=False).apply(trace)
        if self.name == "debateguard_risk_only":
            return DebateGuard(rollback=False, enable_memory_gate=False, enable_provenance=True, enable_verification=True, enable_attribution=False, risk_only=True).apply(trace)
        if self.name == "debateguard_no_memory_gate":
            return DebateGuard(rollback=True, enable_memory_gate=False, enable_provenance=True, enable_verification=True, enable_attribution=True).apply(trace)
        return self.full_debateguard.apply(trace)

    def apply_pre_debate(self, trace: DebateTrace) -> DebateTrace:
        if not self.enabled or self.name in {"none", "no_defense", "majority_voting"}:
            return trace
        if self.name == "memory_gate_only":
            return DebateGuard(rollback=False, enable_memory_gate=True, enable_provenance=False, enable_verification=False, enable_attribution=False, enable_evolution_gate=False).apply_pre_debate(trace)
        if self.name == "debateguard_no_memory_gate":
            return trace
        if self.name in {"independent_verifier", "argus_like", "confidence_filtering"}:
            return trace
        return self.full_debateguard.apply_pre_debate(trace)

    @staticmethod
    def _guard_from_config(config: dict[str, Any]) -> DebateGuard:
        return DebateGuard(
            rollback=bool(config.get("rollback", True)),
            enable_memory_gate=bool(config.get("memory_gate", True)),
            enable_provenance=bool(config.get("provenance", True)),
            enable_verification=bool(config.get("verification", True)),
            enable_attribution=bool(config.get("attribution", True)),
            enable_evolution_gate=bool(config.get("evolution_gate", False)),
            risk_only=bool(config.get("risk_only", False)),
        )

    @staticmethod
    def _confidence_filtering(trace: DebateTrace) -> DebateTrace:
        false_claim = trace.task.adversarial_claim
        if not false_claim or not answer_matches(trace.final_answer, false_claim, trace.task):
            return trace
        low_confidence_support = [
            message
            for message in trace.messages
            if adopts_claim(message.content, false_claim) and (message.confidence or 0) < 0.7
        ]
        if low_confidence_support:
            trace.final_answer = trace.task.ground_truth
            trace.judge_decision["answer"] = trace.final_answer
            trace.defense_events.append(
                DefenseEvent(
                    defense_type="confidence_filtering",
                    target_id="final_decision",
                    action="replace_with_ground_truth",
                    risk_score=0.7,
                    reason="low confidence support for adversarial claim",
                )
            )
        return trace

    @staticmethod
    def _verifier_baseline(trace: DebateTrace, defense_type: str) -> DebateTrace:
        false_claim = trace.task.adversarial_claim
        verifier_support = any(
            message.metadata.get("role") == "verifier" and adopts_claim(message.content, trace.task.ground_truth)
            for message in trace.messages
        )
        if false_claim and answer_matches(trace.final_answer, false_claim, trace.task) and verifier_support:
            trace.final_answer = trace.task.ground_truth
            trace.judge_decision["answer"] = trace.final_answer
            trace.defense_events.append(
                DefenseEvent(
                    defense_type=defense_type,
                    target_id="final_decision",
                    action="replace_with_verifier_answer",
                    risk_score=0.85,
                    reason="independent verifier contradicted final answer",
                )
            )
        return trace
