from __future__ import annotations

from debateguard.schemas import Claim


class PropagationRiskScorer:
    def score(
        self,
        claim: Claim,
        influence_centrality: float = 0.0,
        adoption_count: int = 0,
        source_risk: float = 0.0,
        memory_write_probability: float = 0.0,
    ) -> float:
        if claim.verification_status == "contradicted":
            verification_risk = 1.0
        elif claim.verification_status == "supported":
            verification_risk = -1.0
        elif claim.verification_status == "insufficient_evidence":
            verification_risk = 0.3
        else:
            verification_risk = 0.3
        risk = (
            0.20 * claim.uncertainty
            + 0.20 * claim.safety_relevance
            + 0.20 * influence_centrality
            + 0.15 * min(adoption_count / 5, 1)
            + 0.15 * memory_write_probability
            + 0.10 * source_risk
            + 0.20 * verification_risk
        )
        claim.risk_score = round(max(0.0, min(1.0, risk)), 4)
        return round(max(0.0, min(1.0, risk)), 4)
