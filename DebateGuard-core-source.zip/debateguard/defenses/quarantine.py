from __future__ import annotations

from debateguard.schemas import DefenseEvent, DebateTrace


class QuarantineManager:
    def quarantine_memory(self, trace: DebateTrace, memory_id: str, reason: str, risk_score: float) -> None:
        for update in trace.memory_updates:
            if update.memory_item.memory_id == memory_id:
                update.memory_item.quarantined = True
                update.action = "quarantined"
                update.reason = reason
                trace.defense_events.append(
                    DefenseEvent(
                        defense_type="quarantine",
                        target_id=memory_id,
                        action="quarantine_memory",
                        risk_score=risk_score,
                        reason=reason,
                    )
                )

