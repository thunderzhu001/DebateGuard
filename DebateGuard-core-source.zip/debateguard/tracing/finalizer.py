from __future__ import annotations

from debateguard.schemas import DebateTrace


class TraceFinalizer:
    """Freeze a mutable trace into deterministic provenance IDs."""

    def finalize(self, trace: DebateTrace) -> DebateTrace:
        trace.trace_id = f"trace_{trace.experiment_name}_ep{trace.episode_id}_{trace.task.task_id}"
        trace.experiment_id = trace.experiment_name
        message_id_map: dict[str, str] = {}
        claim_id_map: dict[str, str] = {}
        memory_id_map: dict[str, str] = {}
        self._finalize_messages(trace, message_id_map, claim_id_map)
        self._finalize_attack_events(trace)
        self._finalize_memory_updates(trace, message_id_map, claim_id_map, memory_id_map)
        self._finalize_agent_memory(trace, message_id_map, claim_id_map, memory_id_map)
        self._finalize_message_memory_retrievals(trace, memory_id_map)
        self._finalize_defense_events(trace, claim_id_map, memory_id_map)
        self._finalize_debateguard_metadata(trace, claim_id_map, memory_id_map, message_id_map)
        return trace

    def _finalize_messages(
        self,
        trace: DebateTrace,
        message_id_map: dict[str, str],
        claim_id_map: dict[str, str],
    ) -> None:
        for index, message in enumerate(trace.messages, start=1):
            old_id = message.message_id
            new_id = f"msg_ep{trace.episode_id}_{index:04d}"
            message_id_map[old_id] = new_id
            message.message_id = new_id
            message.trace_id = trace.trace_id
            message.episode_id = trace.episode_id
            message.role = message.role or str(message.metadata.get("role", ""))
            message.timestamp = f"deterministic:{trace.seed}:{trace.episode_id}:message:{index}"
        for message in trace.messages:
            message.parent_message_ids = [message_id_map.get(parent_id, parent_id) for parent_id in message.parent_message_ids]
            for claim_index, claim in enumerate(message.claims, start=1):
                old_claim_id = claim.claim_id
                new_claim_id = f"claim_{message.message_id}_{claim_index:02d}"
                claim_id_map[old_claim_id] = new_claim_id
                claim.claim_id = new_claim_id
                claim.trace_id = trace.trace_id
                claim.source_message_id = message_id_map.get(claim.source_message_id, message.message_id)
            message.claim_ids = [claim.claim_id for claim in message.claims]
        trace.claims = [claim for message in trace.messages for claim in message.claims]
        trace.accepted_claim_ids = [claim_id_map.get(claim_id, claim_id) for claim_id in trace.accepted_claim_ids]
        trace.rejected_claim_ids = [claim_id_map.get(claim_id, claim_id) for claim_id in trace.rejected_claim_ids]

    @staticmethod
    def _finalize_attack_events(trace: DebateTrace) -> None:
        for index, event in enumerate(trace.attack_events, start=1):
            event.event_id = f"attack_ep{trace.episode_id}_{index:03d}"
            event.timestamp = f"deterministic:{trace.seed}:{trace.episode_id}:attack:{index}"

    @staticmethod
    def _finalize_memory_updates(
        trace: DebateTrace,
        message_id_map: dict[str, str],
        claim_id_map: dict[str, str],
        memory_id_map: dict[str, str],
    ) -> None:
        for index, update in enumerate(trace.memory_updates, start=1):
            update.update_id = f"memupd_ep{trace.episode_id}_{index:03d}"
            update.timestamp = f"deterministic:{trace.seed}:{trace.episode_id}:memory_update:{index}"
            old_memory_id = update.memory_item.memory_id
            new_memory_id = f"mem_ep{trace.episode_id}_{index:03d}"
            memory_id_map[old_memory_id] = new_memory_id
            update.memory_item.memory_id = new_memory_id
            update.memory_item.source_trace_id = trace.trace_id if update.memory_item.source_trace_id else None
            if update.memory_item.source_message_id:
                update.memory_item.source_message_id = message_id_map.get(update.memory_item.source_message_id, update.memory_item.source_message_id)
            update.memory_item.source_message_ids = [message_id_map.get(message_id, message_id) for message_id in update.memory_item.source_message_ids]
            update.memory_item.source_claim_ids = [claim_id_map.get(claim_id, claim_id) for claim_id in update.memory_item.source_claim_ids]
            update.memory_item.created_at = f"deterministic:{trace.seed}:{trace.episode_id}:memory:{index}"

    @staticmethod
    def _finalize_agent_memory(
        trace: DebateTrace,
        message_id_map: dict[str, str],
        claim_id_map: dict[str, str],
        memory_id_map: dict[str, str],
    ) -> None:
        for agent in trace.agents:
            for item in agent.memory:
                if item.memory_id in memory_id_map:
                    item.memory_id = memory_id_map[item.memory_id]
                if item.source_message_id:
                    item.source_message_id = message_id_map.get(item.source_message_id, item.source_message_id)
                item.source_message_ids = [message_id_map.get(message_id, message_id) for message_id in item.source_message_ids]
                item.source_claim_ids = [claim_id_map.get(claim_id, claim_id) for claim_id in item.source_claim_ids]
                item.created_at = item.created_at if item.created_at.startswith("deterministic:") else f"deterministic:{trace.seed}:{trace.episode_id}:agent_memory"

    @staticmethod
    def _finalize_message_memory_retrievals(trace: DebateTrace, memory_id_map: dict[str, str]) -> None:
        for message in trace.messages:
            retrieved_ids = message.metadata.get("retrieved_memory_ids", [])
            if isinstance(retrieved_ids, list):
                message.metadata["retrieved_memory_ids"] = [memory_id_map.get(memory_id, memory_id) for memory_id in retrieved_ids]

    @staticmethod
    def _finalize_defense_events(
        trace: DebateTrace,
        claim_id_map: dict[str, str],
        memory_id_map: dict[str, str],
    ) -> None:
        for index, event in enumerate(trace.defense_events, start=1):
            event.event_id = f"defense_ep{trace.episode_id}_{index:03d}"
            event.target_id = claim_id_map.get(event.target_id, memory_id_map.get(event.target_id, event.target_id))
            event.timestamp = f"deterministic:{trace.seed}:{trace.episode_id}:defense:{index}"

    @staticmethod
    def _finalize_debateguard_metadata(
        trace: DebateTrace,
        claim_id_map: dict[str, str],
        memory_id_map: dict[str, str],
        message_id_map: dict[str, str],
    ) -> None:
        debateguard_meta = trace.metadata.get("debateguard")
        if not isinstance(debateguard_meta, dict):
            return
        for item in debateguard_meta.get("risky_claims", []):
            if isinstance(item, dict) and item.get("claim_id") in claim_id_map:
                item["claim_id"] = claim_id_map[item["claim_id"]]
        for item in debateguard_meta.get("attribution", []):
            if not isinstance(item, dict):
                continue
            suspected_id = item.get("suspected_source_id")
            if suspected_id in message_id_map:
                item["suspected_source_id"] = message_id_map[suspected_id]
            if suspected_id in memory_id_map:
                item["suspected_source_id"] = memory_id_map[suspected_id]
