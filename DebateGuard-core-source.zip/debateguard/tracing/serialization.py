from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

from debateguard.schemas import DebateTrace


def trace_to_json(trace: DebateTrace) -> str:
    return json.dumps(trace.model_dump(mode="json"), indent=2, sort_keys=True, ensure_ascii=False)


def trace_hash(trace: DebateTrace) -> str:
    normalized = trace.model_dump(mode="json")
    normalized.pop("trace_id", None)
    metadata = normalized.get("metadata")
    if isinstance(metadata, dict):
        metadata.pop("trace_hash", None)
        metadata.pop("run_slug", None)
        metadata.pop("cache_hit", None)
        metadata.pop("cache_hit_count", None)
        metadata.pop("message_count", None)
        metadata.pop("provider_returned_models", None)
    for message in normalized.get("messages", []):
        if isinstance(message, dict) and isinstance(message.get("metadata"), dict):
            message["metadata"].pop("cache_hit", None)
    raw = json.dumps(normalized, sort_keys=True, ensure_ascii=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def save_trace(trace: DebateTrace, output_dir: str | Path, *, overwrite: bool = True) -> Path:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f"{trace.experiment_name}_{trace.task.task_id}_ep{trace.episode_id}_{trace.trace_id}.json"
    if path.exists() and not overwrite:
        raise FileExistsError(f"Trace already exists: {path}")
    tmp = path.with_name(f".{path.name}.tmp")
    tmp.write_text(trace_to_json(trace), encoding="utf-8")
    os.replace(tmp, path)
    return path
