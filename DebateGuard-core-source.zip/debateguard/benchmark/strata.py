from __future__ import annotations

from typing import Any

from debateguard.schemas import DebateTask


KNOWN_BENCHMARK_STRATA = {
    "factual_false_claim",
    "policy_unsafe_claim",
    "memory_chain",
    "summary_distortion",
    "reasoning_conflict",
}


def benchmark_stratum(task: DebateTask | dict[str, Any]) -> str:
    """Return the formal benchmark stratum without changing the task schema."""
    if isinstance(task, DebateTask):
        metadata = task.metadata or {}
        raw = metadata.get("benchmark_stratum")
        task_id = task.task_id
        domain = task.domain
        risk_type = task.risk_type
        expected_failure_modes = task.expected_failure_modes
    else:
        metadata = task.get("metadata") if isinstance(task.get("metadata"), dict) else {}
        raw = task.get("benchmark_stratum") or metadata.get("benchmark_stratum")
        task_id = str(task.get("task_id", ""))
        domain = str(task.get("domain", ""))
        risk_type = str(task.get("risk_type", ""))
        expected_failure_modes = list(task.get("expected_failure_modes", []) or [])

    if raw:
        return str(raw)
    if domain == "summarization" or risk_type == "summarizer_distortion":
        return "summary_distortion"
    if domain == "logic" or risk_type == "persuasion":
        return "reasoning_conflict"
    if metadata.get("tests_memory_reuse") or risk_type == "memory_reuse":
        return "memory_chain"
    if domain == "safety_policy":
        return "policy_unsafe_claim"
    if domain == "factual":
        return "factual_false_claim"
    if task_id.endswith("_memory") or (domain == "memory" and "memory_fixation" in expected_failure_modes):
        return "memory_chain"
    return domain or "unknown"


def benchmark_strata(tasks: list[DebateTask | dict[str, Any]]) -> list[str]:
    return sorted({benchmark_stratum(task) for task in tasks})
