from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from debateguard.schemas import DebateTask


BENCHMARK_SCHEMA_VERSION = "2.1"
DEFAULT_BENCHMARK_VERSION = "safedebate-evolvebench-v0.1"
VALID_REVIEW_STATUSES = {"draft", "reviewed", "locked"}
VALID_SOURCE_TYPES = {"synthetic", "public_adapted", "human_authored", "unknown"}


@dataclass(frozen=True)
class BenchmarkBundle:
    tasks: list[DebateTask]
    benchmark_version: str
    benchmark_hash: str
    schema_version: str
    source_path: str
    review_statuses: list[str]

    def metadata(self) -> dict[str, object]:
        return {
            "benchmark_version": self.benchmark_version,
            "benchmark_hash": self.benchmark_hash,
            "benchmark_schema_version": self.schema_version,
            "benchmark_source_path": self.source_path,
            "benchmark_review_statuses": ",".join(self.review_statuses),
        }


def read_tasks_jsonl(path: str | Path) -> list[DebateTask]:
    task_path = Path(path)
    tasks = [DebateTask(**json.loads(line)) for line in task_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    validate_tasks(tasks)
    freeze_task_hashes(tasks)
    return tasks


def write_tasks_jsonl(tasks: list[DebateTask], path: str | Path) -> Path:
    task_path = Path(path)
    task_path.parent.mkdir(parents=True, exist_ok=True)
    freeze_task_hashes(tasks)
    lines = [json.dumps(task.model_dump(mode="json"), sort_keys=True, ensure_ascii=False) for task in tasks]
    task_path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    return task_path


def load_tasks(config: dict[str, Any]) -> list[DebateTask]:
    return load_benchmark(config).tasks


def load_benchmark(config: dict[str, Any]) -> BenchmarkBundle:
    has_inline_items = "items" in config
    if "items" in config:
        tasks = [DebateTask(**item) for item in config["items"]]
        source_path = "<inline>"
        benchmark_version = str(config.get("benchmark_version", "inline-dev"))
        schema_version = str(config.get("schema_version", BENCHMARK_SCHEMA_VERSION))
    else:
        path = config.get("path")
        if not path:
            raise ValueError("Task config must include either 'items' or 'path'.")
        task_path = Path(path)
        source_path = str(task_path)
        if task_path.suffix == ".jsonl":
            tasks = [DebateTask(**json.loads(line)) for line in task_path.read_text(encoding="utf-8").splitlines() if line.strip()]
            raw_metadata: dict[str, Any] = {}
        elif task_path.suffix == ".json":
            raw = json.loads(task_path.read_text(encoding="utf-8"))
            raw_metadata = raw.get("metadata", {}) if isinstance(raw, dict) else {}
            items = raw.get("tasks", raw) if isinstance(raw, dict) else raw
            tasks = [DebateTask(**item) for item in items]
        else:
            raw = yaml.safe_load(task_path.read_text(encoding="utf-8"))
            raw_metadata = raw.get("metadata", {}) if isinstance(raw, dict) else {}
            items = raw.get("tasks", raw) if isinstance(raw, dict) else raw
            tasks = [DebateTask(**item) for item in items]
        benchmark_version = str(config.get("benchmark_version") or raw_metadata.get("benchmark_version") or DEFAULT_BENCHMARK_VERSION)
        schema_version = str(config.get("schema_version") or raw_metadata.get("schema_version") or BENCHMARK_SCHEMA_VERSION)

    validate_tasks(tasks)
    freeze_task_hashes(tasks)
    full_hash = compute_benchmark_hash(tasks)
    if not has_inline_items:
        expected_hash = locals().get("raw_metadata", {}).get("benchmark_hash")
        if expected_hash and expected_hash != full_hash:
            raise ValueError(f"Benchmark hash mismatch for {source_path}: expected {expected_hash}, got {full_hash}")

    allowed_statuses = _allowed_review_statuses(config, has_inline_items=has_inline_items)
    filtered = [task for task in tasks if task.review_status in allowed_statuses]
    max_items = config.get("max_items")
    if max_items is not None:
        limit = int(max_items)
        if limit < 1:
            raise ValueError("tasks.max_items must be >= 1 when provided.")
        filtered = filtered[:limit]
    if not filtered:
        raise ValueError(f"No benchmark tasks matched review_status gate {allowed_statuses} in {source_path}.")
    return BenchmarkBundle(
        tasks=filtered,
        benchmark_version=benchmark_version,
        benchmark_hash=full_hash,
        schema_version=schema_version,
        source_path=source_path,
        review_statuses=allowed_statuses,
    )


def freeze_task_hashes(tasks: list[DebateTask]) -> list[DebateTask]:
    for task in tasks:
        task.schema_version = task.schema_version or BENCHMARK_SCHEMA_VERSION
        task.task_hash = compute_task_hash(task)
    return tasks


def compute_task_hash(task: DebateTask) -> str:
    raw = json.dumps(_canonical_task_dict(task), sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def compute_benchmark_hash(tasks: list[DebateTask]) -> str:
    lines = [
        json.dumps(_canonical_task_dict(task), sort_keys=True, ensure_ascii=False, separators=(",", ":"))
        for task in sorted(tasks, key=lambda item: item.task_id)
    ]
    return hashlib.sha256(("\n".join(lines) + ("\n" if lines else "")).encode("utf-8")).hexdigest()


def _canonical_task_dict(task: DebateTask) -> dict[str, Any]:
    data = task.model_dump(mode="json", by_alias=True)
    data.pop("task_hash", None)
    return data


def validate_tasks(tasks: list[DebateTask]) -> None:
    seen: set[str] = set()
    ids = {task.task_id for task in tasks}
    valid_failure_modes = {
        "persuasive_contamination",
        "consensus_collapse",
        "memory_fixation",
        "role_drift",
        "summarizer_distortion",
        "judge_bias",
    }
    blocked_terms = {"explosive recipe", "malware payload", "credential theft", "bioweapon"}
    for task in tasks:
        if task.task_id in seen:
            raise ValueError(f"Duplicate task_id in benchmark: {task.task_id}")
        seen.add(task.task_id)
        if task.review_status not in VALID_REVIEW_STATUSES:
            raise ValueError(f"Task {task.task_id} has invalid review_status: {task.review_status}")
        if task.source_type not in VALID_SOURCE_TYPES:
            raise ValueError(f"Task {task.task_id} has invalid source_type: {task.source_type}")
        if not task.ground_truth.strip():
            raise ValueError(f"Task {task.task_id} has empty ground_truth.")
        if task.adversarial_claim and task.adversarial_claim.strip().lower() == task.ground_truth.strip().lower():
            raise ValueError(f"Task {task.task_id} has false_claim equal to ground_truth.")
        if not task.evidence:
            raise ValueError(f"Task {task.task_id} must include at least one evidence sentence.")
        missing_links = [linked for linked in task.memory_linked_task_ids if linked not in ids]
        if missing_links:
            raise ValueError(f"Task {task.task_id} has missing memory_linked_task_ids: {missing_links}")
        bad_modes = [mode for mode in task.expected_failure_modes if mode not in valid_failure_modes]
        if bad_modes:
            raise ValueError(f"Task {task.task_id} has invalid expected_failure_modes: {bad_modes}")
        combined = " ".join([task.question, task.ground_truth, task.adversarial_claim or "", task.persuasive_argument or ""]).lower()
        if any(term in combined for term in blocked_terms):
            raise ValueError(f"Task {task.task_id} appears to contain unsafe operational content.")
        if task.task_hash and task.task_hash != compute_task_hash(task):
            raise ValueError(f"Task {task.task_id} has stale task_hash.")
        if task.review_status == "locked":
            missing_review_fields = [
                field
                for field, value in {
                    "source_ref": task.source_ref,
                    "ground_truth_rationale": task.ground_truth_rationale,
                    "safety_notes": task.safety_notes,
                    "locked_at": task.locked_at,
                }.items()
                if not value
            ]
            if task.adversarial_claim and not task.false_claim_rationale:
                missing_review_fields.append("false_claim_rationale")
            if missing_review_fields:
                raise ValueError(f"Locked task {task.task_id} is missing review fields: {missing_review_fields}")


def _allowed_review_statuses(config: dict[str, Any], *, has_inline_items: bool) -> list[str]:
    raw = config.get("review_statuses", config.get("allowed_review_statuses", config.get("review_status")))
    if raw is None:
        return ["draft", "reviewed", "locked"] if has_inline_items else ["locked"]
    if isinstance(raw, str):
        statuses = [raw]
    else:
        statuses = list(raw)
    invalid = [status for status in statuses if status not in VALID_REVIEW_STATUSES]
    if invalid:
        raise ValueError(f"Invalid review_status gate values: {invalid}. Valid values: {sorted(VALID_REVIEW_STATUSES)}")
    return statuses
