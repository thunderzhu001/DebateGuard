from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from debateguard.schemas import Role


VALID_ATTACKS = {
    "misinformation_injection",
    "persuasive_adversary",
    "memory_poisoning",
    "role_corruption",
    "consensus_manipulation",
}
VALID_DEFENSES = {
    "none",
    "no_defense",
    "majority_voting",
    "confidence_filtering",
    "independent_verifier",
    "argus_like",
    "memory_gate_only",
    "debateguard_no_provenance",
    "debateguard_no_verification",
    "debateguard_no_memory_gate",
    "debateguard_no_attribution",
    "debateguard_no_rollback",
    "debateguard_risk_only",
    "full_debateguard",
}
VALID_ROLES = set(Role.__args__)
VALID_TOPOLOGIES = {
    "independent",
    "fully_connected",
    "chain",
    "star_judge",
    "critic_defender",
    "hierarchical",
    "rotating_judge",
}


def load_yaml(path: str | Path) -> dict[str, Any]:
    config_path = Path(path)
    with config_path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Config must be a mapping: {config_path}")
    data["_config_path"] = str(config_path)
    return data


def load_config(path: str | Path, default_path: str | Path = "configs/default.yaml") -> dict[str, Any]:
    config_path = Path(path)
    config = load_yaml(config_path)
    default_file = Path(default_path)
    if default_file.exists() and config_path.resolve() != default_file.resolve():
        default_config = load_yaml(default_file)
        default_config.pop("_config_path", None)
        config = merge_config(default_config, config)
        config["_config_path"] = str(config_path)
    validate_config(config)
    return config


def ensure_dir(path: str | Path) -> Path:
    out = Path(path)
    out.mkdir(parents=True, exist_ok=True)
    return out


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def merge_config(default_config: dict[str, Any], override_config: dict[str, Any]) -> dict[str, Any]:
    return deep_merge(default_config, override_config)


def validate_config(config: dict[str, Any]) -> None:
    model_config = config.get("model", {})
    if isinstance(model_config, dict) and model_config.get("model_alias"):
        from debateguard.llm.model_registry import resolve_model_config

        resolve_model_config(model_config)

    topology = config.get("debate", {}).get("topology", "fully_connected")
    if topology not in VALID_TOPOLOGIES:
        raise ValueError(f"Invalid debate.topology '{topology}'. Valid values: {sorted(VALID_TOPOLOGIES)}")

    rounds = int(config.get("debate", {}).get("rounds", config.get("debate", {}).get("max_rounds", 1)))
    if rounds < 1:
        raise ValueError("debate.rounds must be >= 1.")

    for index, agent in enumerate(config.get("agents", []), start=1):
        role = agent.get("role")
        if role not in VALID_ROLES:
            raise ValueError(f"Invalid role for agents[{index}]: {role}. Valid values: {sorted(VALID_ROLES)}")

    for index, attack in enumerate(config.get("attacks", []), start=1):
        attack_type = attack.get("attack_type") or attack.get("type")
        if attack.get("enabled", True) and attack_type not in VALID_ATTACKS:
            raise ValueError(f"Invalid attack type for attacks[{index}]: {attack_type}. Valid values: {sorted(VALID_ATTACKS)}")

    defense_name = config.get("defense", {}).get("name") or config.get("defense", {}).get("type") or "none"
    if defense_name not in VALID_DEFENSES:
        raise ValueError(f"Invalid defense name '{defense_name}'. Valid values: {sorted(VALID_DEFENSES)}")

    seen_task_ids: set[str] = set()
    for index, item in enumerate(config.get("tasks", {}).get("items", []), start=1):
        if not item.get("task_id"):
            raise ValueError(f"tasks.items[{index}] is missing task_id.")
        if item["task_id"] in seen_task_ids:
            raise ValueError(f"Duplicate task_id in config tasks.items: {item['task_id']}")
        seen_task_ids.add(item["task_id"])
        if not item.get("ground_truth"):
            raise ValueError(f"tasks.items[{index}] has empty ground_truth.")


def expand_matrix_config(config: dict[str, Any], run_id: str | None = None) -> list[dict[str, Any]]:
    matrix_spec = config.get("matrix")
    include_variants: set[str] = set()
    model_aliases: list[str] = []
    if isinstance(matrix_spec, dict):
        include_variants = {str(item) for item in matrix_spec.get("include_variants", [])}
        model_aliases = [str(item) for item in matrix_spec.get("model_aliases", [])]
        matrix = matrix_spec.get("variants", [])
    else:
        matrix = matrix_spec
    base_name = config.get("experiment_name", config.get("name", "experiment"))
    base = {key: value for key, value in config.items() if key != "matrix"}
    if not matrix and not model_aliases:
        single = dict(base)
        if run_id:
            single["run_id"] = run_id
        single.setdefault("base_experiment_name", base_name)
        single.setdefault("variant_name", "default")
        validate_config(single)
        return [single]

    expanded: list[dict[str, Any]] = []
    variants = matrix or [{"variant_name": "default"}]
    for index, variant in enumerate(variants, start=1):
        variant_name = variant.get("variant_name") or variant.get("name") or f"variant_{index}"
        if include_variants and str(variant_name) not in include_variants:
            continue
        override = {key: value for key, value in variant.items() if key not in {"name"}}
        aliases = model_aliases or [""]
        for alias in aliases:
            merged = deep_merge(base, override)
            if alias:
                merged.setdefault("model", {})
                merged["model"] = deep_merge(merged["model"], {"model_alias": alias})
                merged["variant_name"] = f"{alias}__{variant_name}"
                merged["experiment_name"] = f"{base_name}__{alias}__{variant_name}"
            else:
                merged["variant_name"] = variant_name
                merged["experiment_name"] = f"{base_name}__{variant_name}"
            merged["base_experiment_name"] = base_name
            if run_id:
                merged["run_id"] = run_id
            validate_config(merged)
            expanded.append(merged)
    if include_variants and not expanded:
        raise ValueError(f"matrix.include_variants selected no variants: {sorted(include_variants)}")
    return expanded
