from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path


DATALLESS_FLAG = 0x40000000


def load_dotenv(path: str | Path = ".env", *, override: bool = False) -> dict[str, str]:
    if os.environ.get("DEBATEGUARD_SKIP_DOTENV") == "1":
        return {}
    env_path = Path(path)
    loaded: dict[str, str] = {}
    if not env_path.exists():
        return loaded
    if _is_dataless(env_path):
        materialized = _materialize_dataless(env_path)
        if not materialized:
            if os.environ.get("DEBATEGUARD_STRICT_DOTENV") == "1":
                raise RuntimeError(
                    f"{env_path} is dataless and could not be materialized"
                )
            return loaded
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = _strip_env_value(value.strip())
        if not key:
            continue
        if override or key not in os.environ:
            os.environ[key] = value
            loaded[key] = value
    return loaded


def _strip_env_value(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1]
    return value


def _is_dataless(path: Path) -> bool:
    try:
        flags = getattr(path.stat(), "st_flags", 0)
    except OSError:
        return False
    return bool(flags & DATALLESS_FLAG)


def _materialize_dataless(path: Path, *, timeout_seconds: float = 15.0) -> bool:
    """Request an iCloud download without exposing the file contents."""
    try:
        subprocess.run(
            ["brctl", "download", str(path.resolve())],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=min(timeout_seconds, 5.0),
        )
    except (FileNotFoundError, OSError, subprocess.SubprocessError):
        return False
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if not _is_dataless(path):
            return True
        time.sleep(0.1)
    return not _is_dataless(path)
