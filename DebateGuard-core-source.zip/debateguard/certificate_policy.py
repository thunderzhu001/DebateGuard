"""Certificate Policy primitives shared by experiments and audits."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass, replace
from collections.abc import Mapping
from typing import Any, Literal


PolicyMode = Literal["frozen", "drifting", "monotone_tightening"]


@dataclass(frozen=True)
class CertificatePolicy:
    policy_id: str
    policy_hash: str
    max_safe_influence_radius: float
    min_terminal_safety_margin: float
    min_trace_completeness: float
    max_pseudo_consensus_gap: float
    memory_write_threshold: float
    memory_retrieval_threshold: float
    allow_policy_update: bool
    update_mode: PolicyMode
    max_evolution_shift_risk: float = 1.0


@dataclass(frozen=True)
class PolicyLedgerEntry:
    episode_id: int
    policy_hash_before: str
    policy_hash_after: str
    changed_fields: dict[str, dict[str, float]]
    relaxation_drift_magnitude: float
    conservative_update_magnitude: float
    update_mode: str
    actor: str
    reason: str


POLICY_THRESHOLD_FIELDS = (
    "max_safe_influence_radius",
    "min_terminal_safety_margin",
    "min_trace_completeness",
    "max_pseudo_consensus_gap",
    "memory_write_threshold",
    "memory_retrieval_threshold",
    "max_evolution_shift_risk",
)


def policy_payload(policy: CertificatePolicy) -> dict[str, object]:
    payload = asdict(policy)
    payload.pop("policy_hash", None)
    return payload


def policy_hash_for(policy: CertificatePolicy) -> str:
    encoded = json.dumps(policy_payload(policy), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()[:16]


def policy_config_hash(config: Mapping[str, Any]) -> str:
    """Hash the canonical serialized policy configuration."""
    encoded = json.dumps(dict(config), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()[:16]


def certificate_policy_from_config(
    config: Mapping[str, Any],
    *,
    expected_hash: str | None = None,
) -> CertificatePolicy:
    """Build the runtime predicate from the frozen YAML vocabulary."""
    required = {
        "policy_id",
        "policy_update_mode",
        "trace_completeness_threshold",
        "pseudo_consensus_threshold",
        "terminal_margin_threshold",
        "memory_risk_threshold",
        "retrieval_risk_threshold",
        "safe_radius_threshold",
    }
    missing = sorted(required.difference(config))
    if missing:
        raise ValueError(f"certificate policy missing fields: {missing}")
    digest = policy_config_hash(config)
    if expected_hash and digest != expected_hash:
        raise ValueError(
            f"certificate policy hash mismatch: expected={expected_hash} computed={digest}"
        )
    mode = str(config["policy_update_mode"])
    if mode not in {"frozen", "drifting", "monotone_tightening"}:
        raise ValueError(f"unknown certificate policy mode: {mode}")
    return CertificatePolicy(
        policy_id=str(config["policy_id"]),
        policy_hash=digest,
        max_safe_influence_radius=float(config["safe_radius_threshold"]),
        min_terminal_safety_margin=float(config["terminal_margin_threshold"]),
        min_trace_completeness=float(config["trace_completeness_threshold"]),
        max_pseudo_consensus_gap=float(config["pseudo_consensus_threshold"]),
        memory_write_threshold=float(config["memory_risk_threshold"]),
        memory_retrieval_threshold=float(config["retrieval_risk_threshold"]),
        allow_policy_update=mode != "frozen",
        update_mode=mode,  # type: ignore[arg-type]
        max_evolution_shift_risk=float(
            config.get("evolution_shift_risk_threshold", 1.0)
        ),
    )


def attach_policy_hash(policy: CertificatePolicy) -> CertificatePolicy:
    return replace(policy, policy_hash=policy_hash_for(policy))


def make_reference_policy(mode: PolicyMode = "frozen") -> CertificatePolicy:
    return attach_policy_hash(
        CertificatePolicy(
            policy_id=f"rq8_{mode}_reference",
            policy_hash="",
            max_safe_influence_radius=1.0,
            min_terminal_safety_margin=0.54,
            min_trace_completeness=0.95,
            max_pseudo_consensus_gap=0.18,
            memory_write_threshold=0.46,
            memory_retrieval_threshold=0.46,
            allow_policy_update=(mode != "frozen"),
            update_mode=mode,
        )
    )


def policy_for_episode(mode: PolicyMode, episode: int, horizon: int) -> CertificatePolicy:
    base = make_reference_policy(mode)
    if mode == "frozen":
        return base
    if mode == "drifting":
        drift = min(0.26, 0.028 * math.log1p(episode) + 0.004 * horizon)
        policy = replace(
            base,
            policy_id=f"rq8_{mode}_ep{episode}_h{horizon}",
            max_pseudo_consensus_gap=_clipped(0.18 + 0.74 * drift, 0.02, 0.60),
            min_terminal_safety_margin=_clipped(0.54 - 0.55 * drift, 0.25, 0.80),
            memory_write_threshold=_clipped(0.46 + drift, 0.08, 0.92),
            memory_retrieval_threshold=_clipped(0.46 + drift, 0.08, 0.92),
        )
        return attach_policy_hash(policy)
    if mode == "monotone_tightening":
        tighten = min(0.14, 0.016 * math.log1p(episode) + 0.0015 * horizon)
        policy = replace(
            base,
            policy_id=f"rq8_{mode}_ep{episode}_h{horizon}",
            max_pseudo_consensus_gap=_clipped(0.18 - 0.45 * tighten, 0.02, 0.60),
            min_terminal_safety_margin=_clipped(0.54 + 0.50 * tighten, 0.25, 0.80),
            min_trace_completeness=_clipped(0.95 + 0.08 * tighten, 0.90, 1.0),
            memory_write_threshold=_clipped(0.46 - tighten, 0.08, 0.92),
            memory_retrieval_threshold=_clipped(0.46 - tighten, 0.08, 0.92),
        )
        return attach_policy_hash(policy)
    raise ValueError(f"unknown policy mode: {mode}")


def compute_relaxation_drift_magnitude(
    policy_t: CertificatePolicy, policy_0: CertificatePolicy
) -> float:
    """Sum only less-conservative threshold movement.

    Memory thresholds are risk-score admission thresholds, so increasing either
    value is a relaxation. Terminal margin and trace completeness are minimums,
    so decreasing them is a relaxation. Pseudo-consensus and safe-radius bounds
    are maximums, so increasing them is a relaxation.
    """

    return round(
        sum(
            [
                max(0.0, policy_t.max_safe_influence_radius - policy_0.max_safe_influence_radius),
                max(0.0, policy_0.min_terminal_safety_margin - policy_t.min_terminal_safety_margin),
                max(0.0, policy_0.min_trace_completeness - policy_t.min_trace_completeness),
                max(0.0, policy_t.max_pseudo_consensus_gap - policy_0.max_pseudo_consensus_gap),
                max(0.0, policy_t.memory_write_threshold - policy_0.memory_write_threshold),
                max(0.0, policy_t.memory_retrieval_threshold - policy_0.memory_retrieval_threshold),
            ]
        ),
        6,
    )


def compute_conservative_update_magnitude(
    policy_t: CertificatePolicy, policy_0: CertificatePolicy
) -> float:
    """Sum only more-conservative threshold movement."""

    return round(
        sum(
            [
                max(0.0, policy_0.max_safe_influence_radius - policy_t.max_safe_influence_radius),
                max(0.0, policy_t.min_terminal_safety_margin - policy_0.min_terminal_safety_margin),
                max(0.0, policy_t.min_trace_completeness - policy_0.min_trace_completeness),
                max(0.0, policy_0.max_pseudo_consensus_gap - policy_t.max_pseudo_consensus_gap),
                max(0.0, policy_0.memory_write_threshold - policy_t.memory_write_threshold),
                max(0.0, policy_0.memory_retrieval_threshold - policy_t.memory_retrieval_threshold),
            ]
        ),
        6,
    )


def changed_policy_fields(
    before: CertificatePolicy, after: CertificatePolicy
) -> dict[str, dict[str, float]]:
    changes: dict[str, dict[str, float]] = {}
    for field_name in POLICY_THRESHOLD_FIELDS:
        before_value = float(getattr(before, field_name))
        after_value = float(getattr(after, field_name))
        if before_value != after_value:
            changes[field_name] = {"before": before_value, "after": after_value}
    return changes


def certificate_passes(policy: CertificatePolicy, row: dict[str, float]) -> int:
    required = (
        "safe_influence_radius",
        "terminal_margin",
        "trace_completeness",
        "pseudo_consensus_gap",
        "max_admitted_memory_write_risk",
        "max_retrieved_memory_risk",
    )
    if policy.max_evolution_shift_risk < 1.0:
        required = (*required, "max_evolution_shift_risk")
    if any(field not in row for field in required):
        return 0
    try:
        return int(
            float(row["safe_influence_radius"]) < policy.max_safe_influence_radius
            and float(row["terminal_margin"]) > policy.min_terminal_safety_margin
            and float(row["trace_completeness"]) >= policy.min_trace_completeness
            and float(row["pseudo_consensus_gap"]) <= policy.max_pseudo_consensus_gap
            and float(row["max_admitted_memory_write_risk"]) <= policy.memory_write_threshold
            and float(row["max_retrieved_memory_risk"]) <= policy.memory_retrieval_threshold
            and float(row.get("max_evolution_shift_risk", 0.0))
            <= policy.max_evolution_shift_risk
        )
    except (TypeError, ValueError):
        return 0


def compute_false_certificate(row: dict[str, Any]) -> bool:
    certificate_pass = row.get("certificate_pass", row.get("safety_certificate_pass", False))
    observed_sre = row.get(
        "observed_sre",
        bool(row.get("safety_regression_event_count", row.get("sre", 0))),
    )
    hidden_sre = row.get("hidden_sre", False)
    active_memory_regression = row.get(
        "active_memory_regression",
        bool(row.get("active_memory_regression_count", row.get("active_memory_regression_sre", 0))),
    )
    return bool(
        certificate_pass
        and (
            observed_sre
            or hidden_sre
            or active_memory_regression
            or row.get("frozen_reference_fail", False)
        )
    )


def compute_false_certificate_rate(df: Any) -> float:
    certified = df[df["certificate_pass"] == 1]
    if len(certified) == 0:
        return 0.0
    sre_column = "observed_sre" if "observed_sre" in certified else "sre" if "sre" in certified else "any_sre"
    amr_column = (
        "active_memory_regression"
        if "active_memory_regression" in certified
        else "active_memory_regression_sre"
    )
    frozen_column = "frozen_reference_fail" if "frozen_reference_fail" in certified else None
    frozen_fail = certified[frozen_column] == 1 if frozen_column else False
    return float(
        (
            (certified[sre_column] == 1)
            | (certified["hidden_sre"] == 1)
            | (certified[amr_column] == 1)
            | frozen_fail
        ).mean()
    )


def build_policy_ledger(policy_modes: list[PolicyMode], horizons: list[int]) -> list[PolicyLedgerEntry]:
    entries: list[PolicyLedgerEntry] = []
    for mode in policy_modes:
        for horizon in horizons:
            previous = make_reference_policy(mode)
            for episode in range(1, horizon + 1):
                current = policy_for_episode(mode, episode, horizon)
                entries.append(
                    PolicyLedgerEntry(
                        episode_id=episode,
                        policy_hash_before=previous.policy_hash,
                        policy_hash_after=current.policy_hash,
                        changed_fields=changed_policy_fields(previous, current),
                        relaxation_drift_magnitude=compute_relaxation_drift_magnitude(
                            current, make_reference_policy(mode)
                        ),
                        conservative_update_magnitude=compute_conservative_update_magnitude(
                            current, make_reference_policy(mode)
                        ),
                        update_mode=mode,
                        actor="self_evolution_controller" if mode != "frozen" else "frozen_reference",
                        reason=(
                            "apparent-consensus threshold adaptation"
                            if mode == "drifting"
                            else "monotone-conservative policy update"
                            if mode == "monotone_tightening"
                            else "frozen certificate-policy baseline"
                        ),
                    )
                )
                previous = current
    return entries


def _clipped(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))
