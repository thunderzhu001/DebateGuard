from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid4().hex[:12]}"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


Role = Literal[
    "proposer",
    "critic",
    "defender",
    "judge",
    "summarizer",
    "verifier",
    "memory_manager",
    "adversary",
]


class DebateTask(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    task_id: str
    domain: str
    question: str
    choices: list[str] | None = None
    ground_truth: str
    safety_label: str = "safe"
    risk_type: str = "factual"
    evidence: list[str] = Field(default_factory=list)
    adversarial_claim: str | None = Field(default=None, alias="false_claim")
    persuasive_argument: str | None = None
    expected_failure_modes: list[str] = Field(default_factory=list)
    memory_linked_task_ids: list[str] = Field(default_factory=list)
    difficulty: str = "medium"
    source_type: str = "synthetic"
    source_ref: str | None = None
    ground_truth_rationale: str = ""
    false_claim_rationale: str = ""
    safety_notes: str = ""
    review_status: str = "draft"
    reviewer_id: str | None = None
    locked_at: str | None = None
    schema_version: str = "2.1"
    task_hash: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def false_claim(self) -> str | None:
        return self.adversarial_claim


class MemoryItem(BaseModel):
    memory_id: str = Field(default_factory=lambda: new_id("mem"))
    owner_agent_id: str
    scope: Literal["private", "shared"] = "private"
    content: str
    source_trace_id: str | None = None
    source_message_id: str | None = None
    source_message_ids: list[str] = Field(default_factory=list)
    source_claim_ids: list[str] = Field(default_factory=list)
    verified: bool = False
    quarantined: bool = False
    risk_score: float = 0.0
    created_at_episode: int = 0
    reuse_count: int = 0
    created_at: str = Field(default_factory=utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)


class AgentState(BaseModel):
    agent_id: str
    role: Role
    system_prompt: str
    memory: list[MemoryItem] = Field(default_factory=list)
    trust_scores: dict[str, float] = Field(default_factory=dict)
    tool_permissions: list[str] = Field(default_factory=list)
    safety_policy: dict[str, Any] = Field(default_factory=dict)
    evolution_history: list[dict[str, Any]] = Field(default_factory=list)
    is_adversarial: bool = False
    corruption_tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class Claim(BaseModel):
    claim_id: str = Field(default_factory=lambda: new_id("claim"))
    trace_id: str = ""
    text: str
    claim_type: str = "factual"
    source_message_id: str = ""
    source_agent_id: str = ""
    factuality_label: str | None = None
    safety_relevance: float = 0.0
    uncertainty: float = 0.5
    verification_status: str = "unverified"
    adopted_by: list[str] = Field(default_factory=list)
    contradicted_by: list[str] = Field(default_factory=list)
    risk_score: float = 0.0
    metadata: dict[str, Any] = Field(default_factory=dict)


class DebateMessage(BaseModel):
    message_id: str = Field(default_factory=lambda: new_id("msg"))
    trace_id: str = ""
    episode_id: int = 0
    round_id: int
    sender_id: str
    receiver_ids: list[str]
    role: str = ""
    content: str
    claims: list[Claim] = Field(default_factory=list)
    claim_ids: list[str] = Field(default_factory=list)
    confidence: float | None = None
    references: list[str] = Field(default_factory=list)
    parent_message_ids: list[str] = Field(default_factory=list)
    attack_tag: str | None = None
    defense_tag: str | None = None
    timestamp: str = Field(default_factory=utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)


class MemoryUpdate(BaseModel):
    update_id: str = Field(default_factory=lambda: new_id("memupd"))
    agent_id: str
    memory_item: MemoryItem
    action: Literal["proposed", "poisoned", "approved", "quarantined", "rejected", "rolled_back"] = "proposed"
    reason: str = ""
    timestamp: str = Field(default_factory=utc_now)


class AttackEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: new_id("attack"))
    attack_type: str
    target_agent_id: str | None = None
    target_role: str | None = None
    round_id: int | None = None
    claim: str | None = None
    success: bool | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: str = Field(default_factory=utc_now)


class DefenseEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: new_id("defense"))
    defense_type: str
    target_id: str | None = None
    action: str
    risk_score: float = 0.0
    reason: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: str = Field(default_factory=utc_now)


class DefenseTaskView(BaseModel):
    """Public task fields available to a deployment-blind defense."""

    task_id: str
    domain: str
    question: str
    choices: list[str] | None = None
    evidence: list[str] = Field(default_factory=list)
    safety_label: str = "safe"
    risk_type: str = "factual"


class DefenseObservation(BaseModel):
    """Sanitized defense input; evaluation-only oracle labels are excluded."""

    task: DefenseTaskView
    attack_present: bool = False
    oracle_blind: bool = True
    oracle_field_access_count: int = 0

    @classmethod
    def from_task(cls, task: DebateTask, *, attack_present: bool = False) -> "DefenseObservation":
        return cls(
            task=DefenseTaskView(
                task_id=task.task_id,
                domain=task.domain,
                question=task.question,
                choices=list(task.choices) if task.choices else None,
                evidence=list(task.evidence),
                safety_label=task.safety_label,
                risk_type=task.risk_type,
            ),
            attack_present=attack_present,
        )


class DebateTrace(BaseModel):
    trace_id: str = Field(default_factory=lambda: new_id("trace"))
    experiment_id: str = ""
    experiment_name: str = ""
    episode_id: int = 0
    seed: int = 0
    task: DebateTask
    topology: str
    protocol: str = "multi_round"
    agents: list[AgentState]
    messages: list[DebateMessage] = Field(default_factory=list)
    claims: list[Claim] = Field(default_factory=list)
    final_answer: str = ""
    final_decision_agent_id: str = ""
    correct: bool = False
    safe: bool = True
    accepted_claim_ids: list[str] = Field(default_factory=list)
    rejected_claim_ids: list[str] = Field(default_factory=list)
    judge_decision: dict[str, Any] = Field(default_factory=dict)
    memory_updates: list[MemoryUpdate] = Field(default_factory=list)
    attack_events: list[AttackEvent] = Field(default_factory=list)
    defense_events: list[DefenseEvent] = Field(default_factory=list)
    metrics: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
