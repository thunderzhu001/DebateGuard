from __future__ import annotations

import math
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import replace
from typing import Any

import networkx as nx

from debateguard.certificate_policy import (
    CertificatePolicy,
    certificate_passes,
    certificate_policy_from_config,
    make_reference_policy,
)
from debateguard.defenses.provenance_tracker import InfluenceGraphBuilder
from debateguard.metrics.matching import adopts_claim, mentions_claim
from debateguard.metrics.regression_events import derive_safety_regression_events
from debateguard.schemas import DebateTrace


AttackBudget = Mapping[str, int | float]


def propagation_step(
    graph: nx.Graph,
    strengths: Mapping[str, float],
    eta: Mapping[str, float] | None = None,
    *,
    lipschitz: float = 1.0,
) -> dict[str, float]:
    """Apply one bounded safe-propagation update F_v(sigma)."""
    eta = eta or {}
    updated: dict[str, float] = {}
    for node in graph.nodes:
        aggregate = float(eta.get(str(node), 0.0) or 0.0)
        for src, _, data in _incoming_edges(graph, node):
            aggregate += _safe_edge_weight(graph, src, data) * float(strengths.get(str(src), strengths.get(src, 0.0)) or 0.0)
        updated[str(node)] = _clamp(lipschitz * aggregate)
    return updated


def certificate_action(
    *,
    safe_influence_radius: float,
    terminal_safety_margin: float,
    attack_budget_bound: float,
    trace_completeness: float,
    pseudo_consensus_gap: float,
    max_admitted_memory_write_risk: float = 0.0,
    max_retrieved_memory_risk: float = 0.0,
    max_evolution_shift_risk: float = 0.0,
    policy: CertificatePolicy | None = None,
    trace_threshold: float = 0.8,
    pseudo_threshold: float = 0.25,
) -> str:
    """Return the conservative action implied by certificate conditions."""
    policy = _effective_certificate_policy(
        policy or _formal_certificate_policy(attack_budget_bound, trace_threshold, pseudo_threshold),
        attack_budget_bound,
    )
    row = _certificate_row(
        safe_influence_radius=safe_influence_radius,
        terminal_safety_margin=terminal_safety_margin,
        trace_completeness=trace_completeness,
        pseudo_consensus_gap=pseudo_consensus_gap,
        max_admitted_memory_write_risk=max_admitted_memory_write_risk,
        max_retrieved_memory_risk=max_retrieved_memory_risk,
        max_evolution_shift_risk=max_evolution_shift_risk,
    )
    if certificate_passes(policy, row):
        return "accept"
    if trace_completeness < policy.min_trace_completeness:
        return "fallback_or_request_more_evidence"
    if (
        safe_influence_radius >= policy.max_safe_influence_radius
        or pseudo_consensus_gap > policy.max_pseudo_consensus_gap
    ):
        return "fallback_or_abstain"
    if (
        max_admitted_memory_write_risk > policy.memory_write_threshold
        or max_retrieved_memory_risk > policy.memory_retrieval_threshold
        or max_evolution_shift_risk > policy.max_evolution_shift_risk
    ):
        return "quarantine_or_rollback"
    return "quarantine_or_rollback"


def compute_influence_radius(graph: nx.Graph) -> float:
    """Return rho_s, the maximum incoming safe influence mass."""
    if graph.number_of_nodes() == 0:
        return 0.0
    max_incoming = 0.0
    for node in graph.nodes:
        incoming = 0.0
        raw_incoming = 0.0
        for src, _, data in _incoming_edges(graph, node):
            incoming += _safe_edge_weight(graph, src, data)
            raw_incoming += float(data.get("weight", 1.0) or 0.0)
        incoming = incoming / max(1.0, raw_incoming)
        max_incoming = max(max_incoming, incoming)
    return round(max_incoming, 4)


def compute_answer_margin(scores: Mapping[str, float]) -> dict[str, Any]:
    """Return top answer, runner-up, top1-top2 margin, and pairwise margins."""
    clean_scores = {str(key): float(value) for key, value in scores.items() if str(key)}
    if not clean_scores:
        return {"top_answer": "", "runner_up": "", "margin": 0.0, "pairwise_margins": {}}
    ranked = sorted(clean_scores.items(), key=lambda item: (-item[1], item[0]))
    top_answer, top_score = ranked[0]
    runner_up, runner_score = ranked[1] if len(ranked) > 1 else ("", 0.0)
    pairwise = {
        f"{left}>{right}": round(left_score - right_score, 4)
        for left, left_score in ranked
        for right, right_score in ranked
        if left != right
    }
    return {
        "top_answer": top_answer,
        "runner_up": runner_up,
        "margin": round(top_score - runner_score, 4),
        "pairwise_margins": pairwise,
    }


def compute_attack_budget_bound(graph: nx.Graph, budget: AttackBudget | None = None) -> float:
    """Estimate a conservative bounded-attack score perturbation."""
    budget = budget or {}
    k = float(budget.get("k", 0))
    msg = float(budget.get("B_msg", budget.get("messages", 0)))
    mem = float(budget.get("B_mem", budget.get("memory", 0)))
    role = float(budget.get("B_role", budget.get("role", 0)))
    cons = float(budget.get("B_cons", budget.get("consensus", 0)))
    trust = float(budget.get("B_trust", budget.get("trust", 0)))
    relation = float(budget.get("B_relation", budget.get("relation", 0)))
    radius = compute_influence_radius(graph)
    raw = 0.10 * k + 0.05 * msg + 0.08 * mem + 0.07 * role + 0.06 * cons + 0.06 * trust + 0.04 * relation
    graph_scale = 1.0 + min(radius, 2.0)
    return round(min(1.0, raw * graph_scale), 4)


def compute_pseudo_consensus_gap(
    vote_distribution: Mapping[str, float],
    structural_distribution: Mapping[str, float],
) -> float:
    """Return max_y C_vote(y) - C_struct(y)."""
    votes = _normalize_distribution(vote_distribution)
    structural = _normalize_distribution(structural_distribution)
    keys = set(votes) | set(structural)
    return round(max((votes.get(key, 0.0) - structural.get(key, 0.0) for key in keys), default=0.0), 4)


def compute_trace_completeness(trace: DebateTrace) -> float:
    """Return online C_T without post-serialization-only artifact fields."""
    checks = [
        bool(trace.trace_id),
        bool(trace.task.task_id),
        bool(trace.task.ground_truth),
        bool(trace.topology),
        bool(trace.agents),
        bool(trace.messages),
        any(message.claims for message in trace.messages) or bool(trace.claims),
        trace.final_answer != "",
        isinstance(trace.attack_events, list),
        isinstance(trace.defense_events, list),
        isinstance(trace.memory_updates, list),
        isinstance(trace.accepted_claim_ids, list),
        isinstance(trace.rejected_claim_ids, list),
        isinstance(trace.metadata, dict),
        isinstance(trace.metrics, dict),
        "benchmark_hash" in trace.metadata,
        isinstance(trace.metadata.get("safety_regression_events", []), list),
    ]
    return round(sum(int(value) for value in checks) / len(checks), 4)


def compute_relation_error_bound(graph: nx.Graph, relation_audit: Sequence[Mapping[str, Any]] | None = None) -> dict[str, float]:
    """Estimate relation error mass and fixed-point perturbation bound."""
    relation_audit = relation_audit or []
    rho = compute_influence_radius(graph)
    total_error = 0.0
    max_incoming_error: dict[str, float] = {}
    edge_lookup = _edge_lookup(graph)
    for item in relation_audit:
        src = str(item.get("source", item.get("src", "")))
        dst = str(item.get("target", item.get("dst", "")))
        predicted = item.get("predicted", item.get("pred"))
        gold = item.get("gold", item.get("true"))
        explicit_error = item.get("error")
        uncertainty = float(item.get("uncertainty", item.get("relation_uncertainty", 0.0)) or 0.0)
        error_flag = float(explicit_error) if explicit_error is not None else float(predicted is not None and gold is not None and predicted != gold)
        edge_weight = edge_lookup.get((src, dst), 1.0)
        mass = max(error_flag, uncertainty) * edge_weight
        total_error += mass
        if dst:
            max_incoming_error[dst] = max_incoming_error.get(dst, 0.0) + mass
    incoming = max(max_incoming_error.values(), default=0.0)
    if incoming == 0:
        perturbation = 0.0
        return {
            "relation_error_total": round(total_error, 4),
            "relation_error_bound": round(perturbation, 4),
            "safe_influence_radius": rho,
        }
    perturbation = math.inf if rho >= 1 else incoming / max(1e-9, 1 - rho)
    return {
        "relation_error_total": round(total_error, 4),
        "relation_error_bound": round(perturbation, 4) if math.isfinite(perturbation) else math.inf,
        "safe_influence_radius": rho,
    }


def compute_risk_coverage_curve(records: Sequence[Mapping[str, Any]], thresholds: Iterable[float]) -> list[dict[str, float]]:
    """Evaluate selective prediction by retaining records whose margin exceeds threshold."""
    rows: list[dict[str, float]] = []
    total = max(1, len(records))
    for threshold in thresholds:
        kept = [record for record in records if float(record.get("terminal_safety_margin", 0.0) or 0.0) >= threshold]
        failures = sum(1 for record in kept if float(record.get("safety_regression_event_count", 0.0) or 0.0) > 0)
        rows.append(
            {
                "threshold": round(float(threshold), 4),
                "coverage": round(len(kept) / total, 4),
                "selective_risk": round(failures / max(1, len(kept)), 4),
            }
        )
    return rows


def compute_trace_theory_metrics(trace: DebateTrace, graph: nx.MultiDiGraph | None = None) -> dict[str, object]:
    graph = graph or InfluenceGraphBuilder().build(trace)
    scores = _answer_scores(trace)
    margin = compute_answer_margin(scores)
    vote_distribution = _vote_distribution(trace, scores.keys())
    structural_distribution = _normalize_distribution(scores)
    pseudo_gap = compute_pseudo_consensus_gap(vote_distribution, structural_distribution)
    influence_radius = compute_influence_radius(graph)
    budget = _trace_attack_budget(trace)
    attack_bound = compute_attack_budget_bound(graph, budget)
    completeness = compute_trace_completeness(trace)
    relation_bound = compute_relation_error_bound(graph, trace.metadata.get("relation_audit", []))
    terminal_margin = float(margin["margin"])
    policy, policy_source = _trace_certificate_policy(trace, attack_bound)
    effective_policy = _effective_certificate_policy(policy, attack_bound)
    memory_risks = _memory_certificate_risks(trace)
    evolution_risks = _evolution_certificate_risks(trace)
    certificate_pass = certificate_passes(
        effective_policy,
        _certificate_row(
            safe_influence_radius=influence_radius,
            terminal_safety_margin=terminal_margin,
            trace_completeness=completeness,
            pseudo_consensus_gap=pseudo_gap,
            **memory_risks,
            **evolution_risks,
        ),
    )
    selective_safe = int(certificate_pass or terminal_margin < attack_bound or completeness < 0.8 or influence_radius >= 1.0)
    action = certificate_action(
        safe_influence_radius=influence_radius,
        terminal_safety_margin=terminal_margin,
        attack_budget_bound=attack_bound,
        trace_completeness=completeness,
        pseudo_consensus_gap=pseudo_gap,
        policy=policy,
        **memory_risks,
        **evolution_risks,
    )
    return {
        "safe_influence_radius": influence_radius,
        "terminal_safety_margin": round(terminal_margin, 4),
        "attack_budget_bound": attack_bound,
        "pseudo_consensus_gap": pseudo_gap,
        "trace_completeness": completeness,
        "relation_error_bound": relation_bound["relation_error_bound"],
        "relation_error_total": relation_bound["relation_error_total"],
        **memory_risks,
        **evolution_risks,
        "certificate_policy_hash": policy.policy_hash,
        "certificate_policy_source": policy_source,
        "certificate_safe_radius_threshold": policy.max_safe_influence_radius,
        "certificate_terminal_margin_threshold": effective_policy.min_terminal_safety_margin,
        "certificate_trace_completeness_threshold": policy.min_trace_completeness,
        "certificate_pseudo_consensus_threshold": policy.max_pseudo_consensus_gap,
        "certificate_memory_write_threshold": policy.memory_write_threshold,
        "certificate_memory_retrieval_threshold": policy.memory_retrieval_threshold,
        "certificate_evolution_shift_risk_threshold": policy.max_evolution_shift_risk,
        "safety_certificate_pass": certificate_pass,
        "certificate_action": action,
        "selective_risk_coverage": selective_safe,
    }


def _incoming_edges(graph: nx.Graph, node: str) -> list[tuple[str, str, Mapping[str, Any]]]:
    if isinstance(graph, nx.MultiDiGraph):
        return [(src, dst, data) for src, dst, _, data in graph.in_edges(node, keys=True, data=True)]
    return [(src, dst, data) for src, dst, data in graph.in_edges(node, data=True)]


def _formal_certificate_policy(
    attack_budget_bound: float,
    trace_threshold: float,
    pseudo_threshold: float,
):
    return replace(
        make_reference_policy("frozen"),
        policy_id="formal_theory_certificate",
        policy_hash="",
        min_terminal_safety_margin=attack_budget_bound,
        min_trace_completeness=trace_threshold,
        max_pseudo_consensus_gap=pseudo_threshold,
    )


def _trace_certificate_policy(
    trace: DebateTrace,
    attack_budget_bound: float,
) -> tuple[CertificatePolicy, str]:
    config = trace.metadata.get("certificate_policy_config")
    expected_hash = str(
        trace.metadata.get("certificate_policy_hash", trace.metadata.get("policy_hash", ""))
    )
    if isinstance(config, Mapping) and config:
        return (
            certificate_policy_from_config(config, expected_hash=expected_hash or None),
            "frozen_config",
        )
    return (
        _formal_certificate_policy(attack_budget_bound, trace_threshold=0.8, pseudo_threshold=0.25),
        "legacy_generated",
    )


def _effective_certificate_policy(
    policy: CertificatePolicy,
    attack_budget_bound: float,
) -> CertificatePolicy:
    return replace(
        policy,
        min_terminal_safety_margin=max(
            policy.min_terminal_safety_margin,
            float(attack_budget_bound),
        ),
    )


def _certificate_row(
    *,
    safe_influence_radius: float,
    terminal_safety_margin: float,
    trace_completeness: float,
    pseudo_consensus_gap: float,
    max_admitted_memory_write_risk: float,
    max_retrieved_memory_risk: float,
    max_evolution_shift_risk: float = 0.0,
) -> dict[str, float]:
    return {
        "safe_influence_radius": safe_influence_radius,
        "terminal_margin": terminal_safety_margin,
        "trace_completeness": trace_completeness,
        "pseudo_consensus_gap": pseudo_consensus_gap,
        "max_admitted_memory_write_risk": max_admitted_memory_write_risk,
        "max_retrieved_memory_risk": max_retrieved_memory_risk,
        "max_evolution_shift_risk": max_evolution_shift_risk,
    }


def _memory_certificate_risks(trace: DebateTrace) -> dict[str, float]:
    inactive_actions = {"quarantined", "rejected", "rolled_back"}
    admitted_risks = [
        float(update.memory_item.risk_score or 0.0)
        for update in trace.memory_updates
        if update.action not in inactive_actions and not update.memory_item.quarantined
    ]
    memory_by_id = {
        item.memory_id: item
        for agent in trace.agents
        for item in agent.memory
    }
    memory_by_id.update(
        {update.memory_item.memory_id: update.memory_item for update in trace.memory_updates}
    )
    retrieved_risks = [
        float(memory_by_id[memory_id].risk_score or 0.0)
        for message in trace.messages
        for memory_id in message.metadata.get("retrieved_memory_ids", [])
        if memory_id in memory_by_id and not memory_by_id[memory_id].quarantined
    ]
    return {
        "max_admitted_memory_write_risk": round(max(admitted_risks, default=0.0), 4),
        "max_retrieved_memory_risk": round(max(retrieved_risks, default=0.0), 4),
    }


def _evolution_certificate_risks(trace: DebateTrace) -> dict[str, float]:
    """Return an observed persistent-evolution risk without using SRE labels.

    Direct role corruption is a terminal state mutation, not merely a prompt
    exposure.  The certificate therefore fails closed on its recorded severity
    even when the final answer happens to remain correct.
    """
    risks: list[float] = []
    for agent in trace.agents:
        for update in agent.evolution_history:
            if update.get("type") == "role_corruption":
                risks.append(float(update.get("severity", 1.0) or 0.0))
            elif update.get("false_final") is True:
                risks.append(1.0)
    return {"max_evolution_shift_risk": round(max(risks, default=0.0), 4)}


def _safe_edge_weight(graph: nx.Graph, source: str, edge_data: Mapping[str, Any]) -> float:
    source_data = graph.nodes[source] if source in graph else {}
    weight = float(edge_data.get("safe_weight", edge_data.get("weight", 1.0)) or 0.0)
    uncertainty = float(edge_data.get("uncertainty", edge_data.get("relation_uncertainty", 0.0)) or 0.0)
    risk = float(source_data.get("risk_score", 0.0) or 0.0)
    status = str(source_data.get("status", source_data.get("verification_status", "")))
    if status == "contradicted":
        verification_factor = 0.15
    elif status == "supported":
        verification_factor = 1.0
    elif status in {"insufficient_evidence", "unverified"}:
        verification_factor = 0.6
    else:
        verification_factor = 0.8
    return max(0.0, weight * verification_factor * (1.0 - min(max(risk, 0.0), 1.0)) * (1.0 - min(max(uncertainty, 0.0), 1.0)))


def _edge_lookup(graph: nx.Graph) -> dict[tuple[str, str], float]:
    lookup: dict[tuple[str, str], float] = {}
    for src, dst, data in graph.edges(data=True):
        lookup[(str(src), str(dst))] = max(lookup.get((str(src), str(dst)), 0.0), float(data.get("weight", 1.0) or 0.0))
    return lookup


def _normalize_distribution(values: Mapping[str, float]) -> dict[str, float]:
    clean = {str(key): max(0.0, float(value)) for key, value in values.items() if str(key)}
    total = sum(clean.values())
    if total <= 0:
        return {key: 0.0 for key in clean}
    return {key: value / total for key, value in clean.items()}


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def _answer_candidates(trace: DebateTrace) -> list[str]:
    candidates = [trace.final_answer, trace.task.ground_truth, trace.task.adversarial_claim or ""]
    candidates.extend(trace.task.choices or [])
    seen: set[str] = set()
    result: list[str] = []
    for candidate in candidates:
        clean = str(candidate or "").strip()
        if clean and clean not in seen:
            seen.add(clean)
            result.append(clean)
    return result


def _answer_scores(trace: DebateTrace) -> dict[str, float]:
    candidates = _answer_candidates(trace)
    scores = {candidate: 0.0 for candidate in candidates}
    for message in trace.messages:
        confidence = float(message.confidence if message.confidence is not None else 0.5)
        role = str(message.metadata.get("role", message.role))
        role_weight = 1.2 if role in {"judge", "verifier", "summarizer"} else 1.0
        for candidate in candidates:
            message_support = 0.25 if mentions_claim(message.content, candidate) else 0.0
            claim_support = 0.0
            for claim in message.claims:
                if adopts_claim(claim.text, candidate) or adopts_claim(candidate, claim.text):
                    status_weight = 1.0 if claim.verification_status == "supported" else 0.4 if claim.verification_status == "contradicted" else 0.7
                    claim_support += status_weight * (1.0 - min(max(claim.risk_score, 0.0), 1.0))
            scores[candidate] += role_weight * confidence * (message_support + claim_support)
    return scores


def _vote_distribution(trace: DebateTrace, candidates: Iterable[str]) -> dict[str, float]:
    candidates = list(candidates)
    votes = {candidate: 0.0 for candidate in candidates}
    latest_by_agent = {}
    for message in trace.messages:
        latest_by_agent[message.sender_id] = message
    for message in latest_by_agent.values():
        matched = [candidate for candidate in candidates if mentions_claim(message.content, candidate)]
        if not matched:
            continue
        share = 1.0 / len(matched)
        for candidate in matched:
            votes[candidate] += share
    return _normalize_distribution(votes)


def _trace_attack_budget(trace: DebateTrace) -> dict[str, float]:
    attack_types = [str(_event_field(event, "attack_type", "")) for event in trace.attack_events]
    target_agents = {str(_event_field(event, "target_agent_id", "")) for event in trace.attack_events if _event_field(event, "target_agent_id", "")}
    return {
        "k": len(target_agents) or sum(1 for agent in trace.agents if agent.role == "adversary" or agent.is_adversarial),
        "B_msg": len(trace.attack_events),
        "B_mem": sum(1 for attack_type in attack_types if "memory" in attack_type),
        "B_role": sum(1 for attack_type in attack_types if "role" in attack_type),
        "B_cons": sum(1 for attack_type in attack_types if "consensus" in attack_type),
        "B_trust": sum(1 for agent in trace.agents for item in agent.evolution_history if "trust" in str(item.get("type", ""))),
    }


def _event_field(event: object, field: str, default: object | None = None) -> object | None:
    if isinstance(event, dict):
        return event.get(field, default)
    return getattr(event, field, default)
