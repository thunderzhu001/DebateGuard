from __future__ import annotations

from typing import Any

__all__ = [
    "attach_safety_regression_events",
    "compute_metrics",
    "compute_safety_regression_metrics",
    "compute_trace_theory_metrics",
    "derive_safety_regression_events",
    "trace_to_result_row",
]


def __getattr__(name: str) -> Any:
    if name in __all__:
        from debateguard.metrics.compute import compute_metrics, compute_safety_regression_metrics, trace_to_result_row
        from debateguard.metrics.regression_events import attach_safety_regression_events, derive_safety_regression_events
        from debateguard.metrics.theory import compute_trace_theory_metrics

        return {
            "attach_safety_regression_events": attach_safety_regression_events,
            "compute_metrics": compute_metrics,
            "compute_safety_regression_metrics": compute_safety_regression_metrics,
            "compute_trace_theory_metrics": compute_trace_theory_metrics,
            "derive_safety_regression_events": derive_safety_regression_events,
            "trace_to_result_row": trace_to_result_row,
        }[name]
    raise AttributeError(name)
