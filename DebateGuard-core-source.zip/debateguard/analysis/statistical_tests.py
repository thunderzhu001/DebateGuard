from __future__ import annotations

import math
import random
from statistics import mean, pstdev


def bootstrap_ci(values: list[float], *, confidence: float = 0.95, n_boot: int = 1000, seed: int = 42) -> tuple[float, float, float]:
    if not values:
        return (0.0, 0.0, 0.0)
    rng = random.Random(seed)
    samples = []
    for _ in range(n_boot):
        draw = [values[rng.randrange(len(values))] for _ in values]
        samples.append(mean(draw))
    samples.sort()
    alpha = 1 - confidence
    lo = samples[int((alpha / 2) * (len(samples) - 1))]
    hi = samples[int((1 - alpha / 2) * (len(samples) - 1))]
    return (mean(values), lo, hi)


def paired_t_test(a: list[float], b: list[float]) -> dict[str, float]:
    diffs = [x - y for x, y in zip(a, b, strict=False)]
    if len(diffs) < 2:
        return {"t": 0.0, "p_approx": 1.0}
    diff_mean = mean(diffs)
    sd = pstdev(diffs)
    if sd == 0:
        return {"t": 0.0, "p_approx": 1.0}
    t_stat = diff_mean / (sd / math.sqrt(len(diffs)))
    p_approx = math.erfc(abs(t_stat) / math.sqrt(2))
    return {"t": round(t_stat, 4), "p_approx": round(p_approx, 6)}


def wilcoxon_signed_rank(a: list[float], b: list[float]) -> dict[str, float]:
    diffs = [x - y for x, y in zip(a, b, strict=False) if x != y]
    if not diffs:
        return {"w": 0.0, "p_approx": 1.0}
    ranked = sorted((abs(diff), 1 if diff > 0 else -1) for diff in diffs)
    w_plus = sum(rank for rank, (_, sign) in enumerate(ranked, start=1) if sign > 0)
    expected = len(diffs) * (len(diffs) + 1) / 4
    variance = len(diffs) * (len(diffs) + 1) * (2 * len(diffs) + 1) / 24
    z = (w_plus - expected) / math.sqrt(variance) if variance else 0.0
    return {"w": round(float(w_plus), 4), "p_approx": round(math.erfc(abs(z) / math.sqrt(2)), 6)}


def cohens_d(a: list[float], b: list[float]) -> float:
    diffs = [x - y for x, y in zip(a, b, strict=False)]
    if not diffs:
        return 0.0
    sd = pstdev(diffs)
    return round(mean(diffs) / sd, 4) if sd else 0.0
