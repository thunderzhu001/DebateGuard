"""Analysis helpers for paper-level DebateGuard experiments."""
