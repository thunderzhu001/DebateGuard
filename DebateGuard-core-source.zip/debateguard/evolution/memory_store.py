from __future__ import annotations

from collections import defaultdict
from typing import Literal

from debateguard.evolution.memory_runtime import MemoryRuntime, rank_memory_items
from debateguard.schemas import MemoryItem


class MemoryStore:
    """Small deterministic memory store for long-horizon safety experiments."""

    def __init__(self, items: list[MemoryItem] | None = None) -> None:
        self._items: dict[str, MemoryItem] = {}
        self._by_owner: dict[str, list[str]] = defaultdict(list)
        self._shared: list[str] = []
        self._runtime = MemoryRuntime()
        for item in items or []:
            self.add(item)

    def add(self, item: MemoryItem) -> None:
        self._items[item.memory_id] = item
        if item.scope == "shared":
            if item.memory_id not in self._shared:
                self._shared.append(item.memory_id)
            return
        if item.memory_id not in self._by_owner[item.owner_agent_id]:
            self._by_owner[item.owner_agent_id].append(item.memory_id)

    def retrieve(
        self,
        agent_id: str,
        query: str,
        scope: Literal["private", "shared", "both"] = "both",
        top_k: int = 3,
        include_quarantined: bool = False,
    ) -> list[MemoryItem]:
        candidates: list[MemoryItem] = []
        if scope in {"private", "both"}:
            candidates.extend(self._items[memory_id] for memory_id in self._by_owner.get(agent_id, []))
        if scope in {"shared", "both"}:
            candidates.extend(self._items[memory_id] for memory_id in self._shared)
        retrieved = rank_memory_items(candidates, query, top_k=top_k, include_quarantined=include_quarantined)
        for item in retrieved:
            item.reuse_count += 1
        return retrieved

    def quarantine(self, memory_id: str, reason: str) -> None:
        item = self._items[memory_id]
        item.quarantined = True
        item.metadata["quarantine_reason"] = reason

    def rollback(self, memory_id: str) -> None:
        item = self._items[memory_id]
        item.quarantined = True
        item.metadata["rolled_back"] = True

    def lineage(self, memory_id: str) -> dict[str, object]:
        return self._runtime.memory_lineage(self._items[memory_id])

    def items(self) -> list[MemoryItem]:
        return list(self._items.values())
