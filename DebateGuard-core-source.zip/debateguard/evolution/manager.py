from __future__ import annotations

from typing import Any

from debateguard.evolution.memory_runtime import MemoryRuntime
from debateguard.metrics.matching import answer_matches, adopts_claim
from debateguard.schemas import AgentState, DebateTrace, MemoryItem, MemoryUpdate


class EvolutionManager:
    def __init__(self, configs: list[dict[str, Any]] | None = None) -> None:
        self.configs = configs or []
        self.memory_runtime = MemoryRuntime()

    def apply(self, trace: DebateTrace) -> DebateTrace:
        enabled = {config["type"]: config for config in self.configs if config.get("enabled", True)}
        if "memory_evolution" in enabled:
            self._memory_evolution(trace, enabled["memory_evolution"])
        if "trust_evolution" in enabled:
            self._trust_evolution(trace, enabled["trust_evolution"])
        if "role_prompt_evolution" in enabled:
            self._role_prompt_evolution(trace)
        if "workflow_evolution" in enabled:
            trace.metadata.setdefault("workflow_evolution", []).append(
                {"action": "recorded", "policy": enabled["workflow_evolution"].get("policy", "verification_aware")}
            )
        self._cap_agent_histories(trace)
        return trace

    def _memory_evolution(self, trace: DebateTrace, config: dict[str, Any]) -> None:
        scope = config.get("scope", "private")
        max_items_per_agent = int(config.get("max_items_per_agent", 50))
        for agent in trace.agents:
            if agent.role not in {"memory_manager", "judge", "summarizer"}:
                continue
            source = trace.messages[-1] if trace.messages else None
            verified = answer_matches(trace.final_answer, trace.task.ground_truth, trace.task)
            content = f"Debate outcome for {trace.task.task_id}: {trace.final_answer}"
            source_claim_ids = [
                claim.claim_id
                for message in trace.messages[-3:]
                for claim in message.claims
                if adopts_claim(claim.text, trace.final_answer)
            ]
            item = MemoryItem(
                owner_agent_id=agent.agent_id,
                scope=scope,
                content=content,
                source_trace_id=trace.trace_id,
                source_message_id=source.message_id if source else None,
                source_message_ids=[source.message_id] if source else [],
                source_claim_ids=source_claim_ids,
                verified=verified,
                risk_score=0.1 if verified else 0.8,
                created_at_episode=trace.episode_id,
                metadata={"evolution_type": "memory_evolution"},
            )
            agent.memory.append(item)
            trace.memory_updates.append(MemoryUpdate(agent_id=agent.agent_id, memory_item=item, action="proposed"))
            agent.evolution_history.append(
                {"type": "memory_evolution", "episode_id": trace.episode_id, "memory_id": item.memory_id, "verified": verified}
            )
            self.memory_runtime.cap_agent_memory(agent, max_items_per_agent)

    def _trust_evolution(self, trace: DebateTrace, config: dict[str, Any]) -> None:
        alpha = float(config.get("alpha", 0.7))
        false_claim = trace.task.adversarial_claim or ""
        for agent in trace.agents:
            for other in trace.agents:
                if other.agent_id == agent.agent_id:
                    continue
                other_messages = [message for message in trace.messages if message.sender_id == other.agent_id]
                supported_truth = any(adopts_claim(message.content, trace.task.ground_truth) for message in other_messages)
                supported_false = bool(false_claim and any(adopts_claim(message.content, false_claim) for message in other_messages))
                signal = 1.0 if supported_truth and not supported_false else 0.2 if supported_false else 0.5
                old = agent.trust_scores.get(other.agent_id, 0.5)
                agent.trust_scores[other.agent_id] = round(alpha * old + (1 - alpha) * signal, 4)
            agent.evolution_history.append({"type": "trust_evolution", "episode_id": trace.episode_id, "trust_scores": dict(agent.trust_scores)})

    def _role_prompt_evolution(self, trace: DebateTrace) -> None:
        false_final = bool(trace.task.adversarial_claim and answer_matches(trace.final_answer, trace.task.adversarial_claim, trace.task))
        for agent in trace.agents:
            if false_final:
                variant = "stricter_verification"
                reason = "false_final_requires_stricter_verification"
                prompt_suffix = "Future debates must require verification before accepting consensus."
            else:
                variant = "evidence_preserving"
                reason = "successful_verified_outcome"
                prompt_suffix = "Preserve evidence-grounded debate behavior."
            if prompt_suffix not in agent.system_prompt:
                agent.system_prompt = f"{agent.system_prompt.rstrip()} {prompt_suffix}".strip()
            agent.metadata["prompt_variant"] = variant
            agent.evolution_history.append(
                {"type": "role_prompt_evolution", "episode_id": trace.episode_id, "false_final": false_final, "variant": variant, "reason": reason}
            )

    def _cap_agent_histories(self, trace: DebateTrace) -> None:
        max_history = 200
        for config in self.configs:
            max_history = int(config.get("max_history_per_agent", max_history))
        if max_history <= 0:
            return
        for agent in trace.agents:
            self.memory_runtime.cap_agent_history(agent, max_history)
