from __future__ import annotations

from collections.abc import Iterable
from typing import Literal

from debateguard.schemas import AgentState, DebateTask, MemoryItem


class MemoryRuntime:
    """Own memory retrieval, reuse accounting, quarantine, rollback, and caps."""

    def retrieve_for_agent(
        self,
        agent: AgentState,
        task: DebateTask,
        context_text: list[str],
        *,
        top_k: int | None = None,
        shared_memory: Iterable[MemoryItem] | None = None,
        scope: Literal["private", "shared", "both"] = "private",
        include_quarantined: bool = False,
    ) -> list[MemoryItem]:
        limit = int(top_k if top_k is not None else agent.metadata.get("memory_top_k", 3))
        if limit <= 0:
            return []
        query = build_memory_query(task, context_text)
        candidates = self._candidate_memories(agent, shared_memory=shared_memory, scope=scope)
        retrieved = rank_memory_items(
            candidates,
            query,
            top_k=limit,
            include_quarantined=include_quarantined,
        )
        for item in retrieved:
            item.reuse_count += 1
        agent.metadata["last_retrieved_memory_ids"] = [item.memory_id for item in retrieved]
        return retrieved

    def quarantine_agent_memory(self, agent: AgentState, memory_id: str, reason: str) -> bool:
        item = self.find_agent_memory(agent, memory_id)
        if item is None:
            return False
        item.quarantined = True
        item.metadata["quarantine_reason"] = reason
        return True

    def rollback_agent_memory(self, agent: AgentState, memory_id: str, reason: str = "rollback") -> bool:
        item = self.find_agent_memory(agent, memory_id)
        if item is None:
            return False
        item.quarantined = True
        item.metadata["rolled_back"] = True
        item.metadata["rollback_reason"] = reason
        return True

    @staticmethod
    def find_agent_memory(agent: AgentState, memory_id: str) -> MemoryItem | None:
        for item in agent.memory:
            if item.memory_id == memory_id:
                return item
        return None

    @staticmethod
    def memory_lineage(item: MemoryItem) -> dict[str, object]:
        return {
            "memory_id": item.memory_id,
            "source_trace_id": item.source_trace_id,
            "source_message_id": item.source_message_id,
            "source_message_ids": list(item.source_message_ids),
            "source_claim_ids": list(item.source_claim_ids),
            "quarantined": item.quarantined,
            "rolled_back": bool(item.metadata.get("rolled_back")),
            "reuse_count": item.reuse_count,
        }

    @staticmethod
    def cap_agent_memory(agent: AgentState, max_items: int) -> None:
        if max_items <= 0 or len(agent.memory) <= max_items:
            return
        agent.memory = agent.memory[-max_items:]

    @staticmethod
    def cap_agent_history(agent: AgentState, max_items: int) -> None:
        if max_items <= 0 or len(agent.evolution_history) <= max_items:
            return
        agent.evolution_history = agent.evolution_history[-max_items:]

    @staticmethod
    def _candidate_memories(
        agent: AgentState,
        *,
        shared_memory: Iterable[MemoryItem] | None = None,
        scope: Literal["private", "shared", "both"] = "private",
    ) -> list[MemoryItem]:
        candidates: list[MemoryItem] = []
        if scope in {"private", "both"}:
            candidates.extend(agent.memory)
        if scope in {"shared", "both"}:
            candidates.extend(shared_memory or [])
        return candidates


def build_memory_query(task: DebateTask, context_text: list[str]) -> str:
    return " ".join([task.question, " ".join(task.choices or []), *(context_text[-2:] if context_text else [])])


def rank_memory_items(
    items: Iterable[MemoryItem],
    query: str,
    *,
    top_k: int = 3,
    include_quarantined: bool = False,
) -> list[MemoryItem]:
    scored: list[tuple[int, str, str, MemoryItem]] = []
    for item in items:
        if item.quarantined and not include_quarantined:
            continue
        score = keyword_overlap(query, item.content)
        if score > 0:
            scored.append((score, item.created_at, item.memory_id, item))
    scored.sort(key=lambda row: (row[0], row[1], row[2]), reverse=True)
    return [item for _, _, _, item in scored[:top_k]]


def keyword_overlap(query: str, content: str) -> int:
    return len(_tokens(query) & _tokens(content))


def _tokens(text: str) -> set[str]:
    return {token.strip(".,:;!?()[]{}\"'").lower() for token in text.split() if len(token.strip(".,:;!?()[]{}\"'")) > 2}
