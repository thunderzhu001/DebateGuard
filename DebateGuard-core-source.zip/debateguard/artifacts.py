from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from debateguard.schemas import DebateTrace


_NUMBERED_COPY_RE = re.compile(r" \d+\.[^.]+$")


def is_numbered_copy(path: str | Path) -> bool:
    return bool(_NUMBERED_COPY_RE.search(Path(path).name))


def discover_json_artifacts(directory: str | Path, *, include_duplicates: bool = False) -> list[Path]:
    paths = sorted(Path(directory).glob("*.json"))
    if include_duplicates:
        return paths
    return [path for path in paths if not is_numbered_copy(path)]


def read_json_artifact(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def load_debate_trace(path: str | Path) -> DebateTrace:
    return DebateTrace(**read_json_artifact(path))


def load_debate_traces(paths: list[Path]) -> list[tuple[Path, DebateTrace]]:
    return [(path, load_debate_trace(path)) for path in paths]


def trace_manifest_row(trace: DebateTrace, path: str | Path) -> dict[str, Any]:
    return {
        "trace_id": trace.trace_id,
        "path": str(path),
        "trace_hash": trace.metadata.get("trace_hash", ""),
        "benchmark_hash": trace.metadata.get("benchmark_hash", ""),
    }


def append_trace_manifest(
    manifest_path: str | Path,
    traces: list[DebateTrace],
    trace_paths: list[Path],
) -> None:
    path = Path(manifest_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        for trace, trace_path in zip(traces, trace_paths, strict=True):
            handle.write(json.dumps(trace_manifest_row(trace, trace_path), sort_keys=True) + "\n")


def write_trace_manifest(
    manifest_path: str | Path,
    traces: list[tuple[Path, DebateTrace]],
    *,
    dry_run: bool = False,
) -> None:
    if dry_run:
        return
    path = Path(manifest_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [json.dumps(trace_manifest_row(trace, trace_path), sort_keys=True) for trace_path, trace in traces]
    path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def read_trace_manifest(path: str | Path) -> list[dict[str, Any]]:
    manifest_path = Path(path)
    if not manifest_path.exists():
        return []
    return [
        json.loads(line)
        for line in manifest_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def remove_numbered_copies(directory: str | Path, *, suffix: str = ".json") -> int:
    path = Path(directory)
    if not path.exists():
        return 0
    normalized_suffix = suffix if suffix.startswith(".") else f".{suffix}"
    removed = 0
    for file_path in path.glob(f"*{normalized_suffix}"):
        if is_numbered_copy(file_path):
            file_path.unlink()
            removed += 1
    return removed
