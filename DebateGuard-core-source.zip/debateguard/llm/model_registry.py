from __future__ import annotations

import hashlib
import os
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


DEFAULT_MODEL_REGISTRY_PATH = "configs/models/registry.yaml"


MODEL_METADATA_FIELDS = (
    "model_family",
    "model_tier",
    "model_alias",
    "model_id",
    "official_reference_id",
    "gateway_resolved_id",
    "provider_gateway",
    "base_url_hash",
    "model_registry_version",
    "model_resolved_at",
    "supports_seed",
    "supports_json_mode",
    "supports_reasoning_control",
    "context_window",
    "max_output_tokens",
)


def load_model_registry(path: str | Path = DEFAULT_MODEL_REGISTRY_PATH) -> dict[str, Any]:
    registry_path = Path(path)
    if not registry_path.exists():
        return {"version": "", "resolved_at": "", "defaults": {}, "models": {}}
    with registry_path.open("r", encoding="utf-8") as handle:
        registry = yaml.safe_load(handle) or {}
    if not isinstance(registry, dict):
        raise ValueError(f"Model registry must be a mapping: {registry_path}")
    registry.setdefault("defaults", {})
    registry.setdefault("models", {})
    return registry


def resolve_model_config(config: dict[str, Any] | None) -> dict[str, Any]:
    raw_config = deepcopy(config or {"provider": "mock"})
    if raw_config.get("_model_registry_resolved"):
        return raw_config

    provider = str(raw_config.get("provider", "mock"))
    alias = str(raw_config.get("model_alias") or raw_config.get("alias") or "")
    registry_path = raw_config.get("registry_path", DEFAULT_MODEL_REGISTRY_PATH)
    registry = load_model_registry(registry_path)

    if alias:
        models = registry.get("models", {})
        if alias not in models:
            raise ValueError(f"Unknown model_alias '{alias}'. Available aliases: {sorted(models)}")
        explicit_overrides = {
            key: value
            for key, value in raw_config.items()
            if key not in {"alias", "model_alias", "registry_path"}
        }
        resolved = _deep_merge(registry.get("defaults", {}), models[alias])
        resolved = _deep_merge(resolved, explicit_overrides)
        resolved["model_alias"] = alias
        resolved["registry_path"] = str(registry_path)
    else:
        resolved = raw_config

    resolved.setdefault("provider", provider)
    resolved = _apply_environment_overrides(resolved)
    if resolved.get("model_id") and not resolved.get("model"):
        resolved["model"] = resolved["model_id"]
    model_id = str(resolved.get("model") or resolved.get("model_id") or provider)
    resolved["model"] = model_id
    resolved["model_id"] = model_id

    metadata_registry = registry if alias else {"version": "", "resolved_at": ""}
    metadata = _build_model_metadata(resolved, metadata_registry)
    resolved["_model_metadata"] = metadata
    resolved["_model_registry_resolved"] = True
    return resolved


def model_metadata(config: dict[str, Any] | None) -> dict[str, Any]:
    return dict(resolve_model_config(config).get("_model_metadata", {}))


def hash_base_url(base_url: str | None) -> str:
    if not base_url:
        return ""
    return hashlib.sha256(str(base_url).rstrip("/").encode("utf-8")).hexdigest()[:16]


def _build_model_metadata(config: dict[str, Any], registry: dict[str, Any]) -> dict[str, Any]:
    model_id = str(config.get("model") or config.get("model_id") or "")
    base_url = str(config.get("base_url", "")).rstrip("/")
    alias = str(config.get("model_alias") or config.get("alias") or model_id or "")
    return {
        "model_family": str(config.get("model_family", "mock" if config.get("provider") == "mock" else "")),
        "model_tier": str(config.get("model_tier", "mock" if config.get("provider") == "mock" else "")),
        "model_alias": alias,
        "model_id": model_id,
        "official_reference_id": str(config.get("official_reference_id", model_id)),
        "gateway_resolved_id": str(config.get("gateway_resolved_id", model_id)),
        "provider_gateway": str(config.get("provider_gateway", config.get("provider", ""))),
        "base_url_hash": hash_base_url(base_url),
        "model_registry_version": str(config.get("model_registry_version", registry.get("version", ""))),
        "model_resolved_at": str(config.get("resolved_at", registry.get("resolved_at", ""))),
        "supports_seed": bool(config.get("supports_seed", False)),
        "supports_json_mode": bool(config.get("supports_json_mode", False)),
        "supports_reasoning_control": bool(config.get("supports_reasoning_control", False)),
        "context_window": int(config.get("context_window", 0) or 0),
        "max_output_tokens": int(config.get("max_output_tokens", 0) or 0),
    }


def _apply_environment_overrides(config: dict[str, Any]) -> dict[str, Any]:
    resolved = deepcopy(config)
    base_url_env = resolved.get("base_url_env")
    if base_url_env and os.getenv(str(base_url_env)):
        resolved["base_url"] = os.environ[str(base_url_env)]
        resolved["provider_gateway"] = os.getenv("DEBATEGUARD_GATEWAY_NAME", "compatible_gateway")
    model_env = resolved.get("model_env")
    if model_env and os.getenv(str(model_env)):
        resolved["model"] = os.environ[str(model_env)]
        resolved["gateway_resolved_id"] = os.environ[str(model_env)]
    return resolved


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = deepcopy(value)
    return merged
