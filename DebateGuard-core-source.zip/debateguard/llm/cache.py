from __future__ import annotations

import hashlib
import json
import stat
import tempfile
from pathlib import Path
from typing import Any


class JsonCache:
    def __init__(self, cache_dir: str | Path = "data/cache") -> None:
        requested = Path(cache_dir)
        self.cache_dir = _runtime_cache_dir(requested)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def key(self, payload: dict[str, Any]) -> str:
        raw = json.dumps(payload, sort_keys=True, ensure_ascii=True)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def get(self, payload: dict[str, Any]) -> dict[str, Any] | None:
        path = self.cache_dir / f"{self.key(payload)}.json"
        if not path.exists():
            return None
        # iCloud dataless cache files can block while macOS localizes them.
        # Skipping them is safe because cache misses are deterministic here.
        flags = getattr(path.stat(), "st_flags", 0)
        if flags & getattr(stat, "UF_COMPRESSED", 0):
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    def set(self, payload: dict[str, Any], value: dict[str, Any]) -> None:
        path = self.cache_dir / f"{self.key(payload)}.json"
        path.write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")


def _runtime_cache_dir(cache_dir: Path) -> Path:
    if _contains_macos_flagged_files(cache_dir):
        return Path(tempfile.gettempdir()) / "debateguard_cache"
    return cache_dir


def _contains_macos_flagged_files(cache_dir: Path, sample_limit: int = 25) -> bool:
    if not cache_dir.exists() or not cache_dir.is_dir():
        return False
    checked = 0
    for path in cache_dir.iterdir():
        if not path.is_file():
            continue
        checked += 1
        try:
            if getattr(path.stat(), "st_flags", 0):
                return True
        except OSError:
            return True
        if checked >= sample_limit:
            return False
    return False
