from __future__ import annotations

import fcntl
import json
import os
import time
from pathlib import Path


def acquire_global_rate_limit(
    *,
    limit: int | None = None,
    state_path: str | Path | None = None,
    window_seconds: float = 60.0,
) -> None:
    effective_limit = int(
        limit
        if limit is not None
        else os.getenv("DEBATEGUARD_GLOBAL_RATE_LIMIT_PER_MINUTE", "0")
    )
    if effective_limit <= 0:
        return
    path = Path(
        state_path
        or os.getenv(
            "DEBATEGUARD_GLOBAL_RATE_LIMIT_STATE",
            "/tmp/debateguard_global_rate_limit.json",
        )
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    while True:
        with path.open("a+", encoding="utf-8") as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            handle.seek(0)
            try:
                timestamps = [float(value) for value in json.load(handle)]
            except (json.JSONDecodeError, TypeError, ValueError):
                timestamps = []
            now = time.time()
            timestamps = [value for value in timestamps if now - value < window_seconds]
            if len(timestamps) < effective_limit:
                timestamps.append(now)
                handle.seek(0)
                handle.truncate()
                json.dump(timestamps, handle)
                handle.flush()
                os.fsync(handle.fileno())
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
                return
            wait_seconds = max(0.01, window_seconds - (now - min(timestamps)) + 0.01)
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        time.sleep(wait_seconds)
