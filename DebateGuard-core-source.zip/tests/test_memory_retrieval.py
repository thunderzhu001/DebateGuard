from __future__ import annotations

from typing import Any

from debateguard.agents.base_agent import DebateAgent
from debateguard.evolution import EvolutionManager
from debateguard.schemas import AgentState, DebateTask, DebateTrace, MemoryItem


class CapturingProvider:
    def __init__(self) -> None:
        self.seen_memory_ids: list[str] = []

    def generate(
        self,
        *,
        agent: AgentState,
        task: DebateTask,
        context: list[str],
        attack_context: dict[str, Any],
        seed: int,
    ) -> dict[str, Any]:
        self.seen_memory_ids = [item.memory_id for item in agent.memory]
        return {
            "content": f"My answer is {task.ground_truth}.",
            "confidence": 0.9,
            "token_cost": 3,
            "latency_ms": 1,
            "provider_response_id": "resp_1",
            "provider_returned_model": "mock-returned",
            "finish_reason": "stop",
            "prompt_tokens": 1,
            "completion_tokens": 2,
            "total_tokens": 3,
        }


def test_agent_retrieves_topical_memory_instead_of_all_memory() -> None:
    task = DebateTask(
        task_id="t1",
        domain="factual",
        question="Which catalyst conclusion should be reused?",
        ground_truth="Catalyst A improved yield",
    )
    relevant = MemoryItem(memory_id="mem_relevant", owner_agent_id="a1", content="Remember Catalyst A improved yield")
    irrelevant = MemoryItem(memory_id="mem_irrelevant", owner_agent_id="a1", content="Old unrelated policy decision")
    agent = DebateAgent(
        AgentState(
            agent_id="a1",
            role="proposer",
            system_prompt="",
            memory=[relevant, irrelevant],
            metadata={"memory_top_k": 1},
        )
    )
    provider = CapturingProvider()

    message = agent.act(task=task, provider=provider, context=[], receiver_ids=[], round_id=1, attack_context={}, seed=7)

    assert provider.seen_memory_ids == ["mem_relevant"]
    assert message.metadata["retrieved_memory_ids"] == ["mem_relevant"]
    assert message.metadata["provider_response_id"] == "resp_1"
    assert message.metadata["provider_returned_model"] == "mock-returned"
    assert message.metadata["total_tokens"] == 3
    assert relevant.reuse_count == 1
    assert irrelevant.reuse_count == 0


def test_role_prompt_evolution_is_idempotent() -> None:
    task = DebateTask(task_id="t1", domain="factual", question="q", ground_truth="true answer", adversarial_claim="false answer")
    agent = AgentState(agent_id="a1", role="proposer", system_prompt="Base prompt.")
    trace = DebateTrace(task=task, topology="fully_connected", agents=[agent], final_answer="true answer")
    manager = EvolutionManager([{"type": "role_prompt_evolution", "enabled": True}])

    manager.apply(trace)
    manager.apply(trace)

    assert agent.system_prompt.count("Preserve evidence-grounded debate behavior.") == 1


def test_memory_evolution_caps_agent_memory_snapshot() -> None:
    task = DebateTask(task_id="t1", domain="factual", question="q", ground_truth="true answer")
    agent = AgentState(
        agent_id="m1",
        role="memory_manager",
        system_prompt="",
        memory=[
            MemoryItem(memory_id="old1", owner_agent_id="m1", content="old one"),
            MemoryItem(memory_id="old2", owner_agent_id="m1", content="old two"),
            MemoryItem(memory_id="old3", owner_agent_id="m1", content="old three"),
        ],
    )
    trace = DebateTrace(task=task, topology="fully_connected", agents=[agent], final_answer="true answer")
    manager = EvolutionManager([{"type": "memory_evolution", "enabled": True, "max_items_per_agent": 2}])

    manager.apply(trace)

    assert len(agent.memory) == 2
    assert [item.memory_id for item in agent.memory] == ["old3", trace.memory_updates[-1].memory_item.memory_id]
