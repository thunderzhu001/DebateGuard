from pathlib import Path

import yaml

from debateguard.certificate_policy import policy_config_hash


def test_archived_v2_policy_matches_its_recorded_identity() -> None:
    root = Path(__file__).resolve().parents[1]
    config = yaml.safe_load((root / "configs/certificate_policy_frozen_v2.yaml").read_text())
    recorded_hash = (root / "configs/frozen_policy_v2_hash.txt").read_text().strip()
    assert policy_config_hash(config) == recorded_hash
