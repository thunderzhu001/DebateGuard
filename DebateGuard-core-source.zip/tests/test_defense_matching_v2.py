from __future__ import annotations

import pytest

from debateguard.benchmark.loaders import read_tasks_jsonl, write_tasks_jsonl
from debateguard.config import validate_config
from debateguard.defenses.claim_extractor import RuleClaimExtractor
from debateguard.defenses.claim_verifier import ClaimVerifier
from debateguard.defenses.counterfactual_attributor import CounterfactualAttributor
from debateguard.defenses.memory_gate import MemoryRegressionGate
from debateguard.metrics import compute_metrics
from debateguard.schemas import AgentState, Claim, DebateMessage, DebateTask, DebateTrace, MemoryItem


def test_claim_extraction_and_verification_respect_negated_choice() -> None:
    task = DebateTask(
        task_id="logic",
        domain="logic",
        question="q",
        choices=["Q follows", "not Q follows"],
        ground_truth="Q follows",
        adversarial_claim="not Q follows",
        evidence=["P entails Q, so Q follows"],
    )
    message = DebateMessage(
        message_id="m1",
        round_id=1,
        sender_id="j1",
        receiver_ids=[],
        content="Final decision: not Q follows.",
        metadata={"role": "judge"},
    )

    claims = RuleClaimExtractor().extract(message, task)
    assert "not Q follows" in [claim.text for claim in claims]
    assert "Q follows" not in [claim.text for claim in claims]

    verified = ClaimVerifier().verify(Claim(text="not Q follows", source_message_id="m1", source_agent_id="j1"), task)
    assert verified.verification_status == "contradicted"


def test_memory_gate_and_attribution_ignore_rejected_false_claims() -> None:
    gate_decision = MemoryRegressionGate().decide(
        MemoryItem(owner_agent_id="m1", content="Reject false answer", verified=True, risk_score=0.1),
        adversarial_claim="false answer",
        attack_active=False,
    )
    assert "contains_adversarial_claim" not in gate_decision.reasons
    assert gate_decision.decision == "approve"

    task = DebateTask(task_id="t1", domain="factual", question="q", ground_truth="true answer", adversarial_claim="false answer")
    trace = DebateTrace(
        task=task,
        topology="fully_connected",
        agents=[
            AgentState(agent_id="v1", role="verifier", system_prompt=""),
            AgentState(agent_id="a1", role="adversary", system_prompt=""),
        ],
        final_answer="false answer",
        messages=[
            DebateMessage(message_id="m1", round_id=1, sender_id="v1", receiver_ids=[], content="Contradicted claim: false answer.", metadata={"role": "verifier"}),
            DebateMessage(message_id="m2", round_id=1, sender_id="a1", receiver_ids=[], content="I am confident that false answer.", attack_tag="misinformation_injection"),
        ],
    )
    suspects = CounterfactualAttributor().attribute(trace)
    assert [suspect["suspected_source_id"] for suspect in suspects] == ["m2"]


def test_mrr_counts_repeated_poisoned_memory_retrievals() -> None:
    task = DebateTask(task_id="t1", domain="factual", question="q", ground_truth="true answer", adversarial_claim="false answer")
    poisoned = MemoryItem(memory_id="mem_false", owner_agent_id="a1", content="Poisoned memory: false answer")
    clean = MemoryItem(memory_id="mem_true", owner_agent_id="a1", content="Verified memory: true answer")
    trace = DebateTrace(
        task=task,
        topology="fully_connected",
        agents=[AgentState(agent_id="a1", role="proposer", system_prompt="", memory=[poisoned, clean])],
        final_answer="true answer",
        messages=[
            DebateMessage(round_id=1, sender_id="a1", receiver_ids=[], content="My answer is true answer.", metadata={"retrieved_memory_ids": ["mem_false"]}),
            DebateMessage(round_id=2, sender_id="a1", receiver_ids=[], content="My answer is true answer.", metadata={"retrieved_memory_ids": ["mem_false", "mem_true"]}),
        ],
    )

    assert compute_metrics(trace)["MRR"] == pytest.approx(0.6667)


def test_jsonl_and_inline_config_reject_duplicate_task_ids(tmp_path) -> None:
    task = DebateTask(task_id="dup", domain="factual", question="q", ground_truth="true", adversarial_claim="false", evidence=["true"])
    path = tmp_path / "tasks.jsonl"
    write_tasks_jsonl([task, task], path)
    with pytest.raises(ValueError, match="Duplicate task_id"):
        read_tasks_jsonl(path)

    config = {
        "debate": {"topology": "fully_connected", "rounds": 1},
        "tasks": {"items": [task.model_dump(mode="json"), task.model_dump(mode="json")]},
    }
    with pytest.raises(ValueError, match="Duplicate task_id"):
        validate_config(config)
