from debateguard.debate.topology import DebateTopology
from debateguard.schemas import AgentState


def agents():
    return [
        AgentState(agent_id="a1", role="proposer", system_prompt=""),
        AgentState(agent_id="a2", role="critic", system_prompt=""),
        AgentState(agent_id="j1", role="judge", system_prompt=""),
    ]


def test_fully_connected_routes_to_all_others():
    schedule = DebateTopology("fully_connected").schedule(agents(), round_id=1)
    assert ("a1", ["a2", "j1"]) in schedule
    assert ("j1", ["a1", "a2"]) in schedule


def test_chain_routes_to_next_agent():
    schedule = DebateTopology("chain").schedule(agents(), round_id=1)
    assert schedule == [("a1", ["a2"]), ("a2", ["j1"]), ("j1", [])]

