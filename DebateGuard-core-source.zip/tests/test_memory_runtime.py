from __future__ import annotations

from debateguard.evolution import MemoryRuntime, MemoryStore
from debateguard.schemas import AgentState, DebateTask, MemoryItem


def test_memory_runtime_and_store_share_retrieval_semantics() -> None:
    task = DebateTask(
        task_id="t1",
        domain="factual",
        question="Which catalyst conclusion should be reused?",
        choices=["Catalyst A improved yield", "Catalyst B reduced yield"],
        ground_truth="Catalyst A improved yield",
    )
    relevant = MemoryItem(memory_id="mem_relevant", owner_agent_id="a1", content="Remember Catalyst A improved yield")
    irrelevant = MemoryItem(memory_id="mem_irrelevant", owner_agent_id="a1", content="Old unrelated policy decision")
    agent = AgentState(agent_id="a1", role="proposer", system_prompt="", memory=[relevant, irrelevant], metadata={"memory_top_k": 1})

    runtime_result = MemoryRuntime().retrieve_for_agent(agent, task, [])
    store_result = MemoryStore([relevant, irrelevant]).retrieve("a1", task.question, top_k=1)

    assert [item.memory_id for item in runtime_result] == ["mem_relevant"]
    assert [item.memory_id for item in store_result] == ["mem_relevant"]


def test_memory_runtime_caps_memory_and_history() -> None:
    agent = AgentState(
        agent_id="a1",
        role="memory_manager",
        system_prompt="",
        memory=[MemoryItem(memory_id=f"mem{i}", owner_agent_id="a1", content=str(i)) for i in range(4)],
        evolution_history=[{"i": i} for i in range(5)],
    )
    runtime = MemoryRuntime()

    runtime.cap_agent_memory(agent, 2)
    runtime.cap_agent_history(agent, 3)

    assert [item.memory_id for item in agent.memory] == ["mem2", "mem3"]
    assert agent.evolution_history == [{"i": 2}, {"i": 3}, {"i": 4}]


def test_memory_runtime_owns_quarantine_rollback_and_lineage() -> None:
    memory = MemoryItem(
        memory_id="mem_lineage",
        owner_agent_id="a1",
        content="Remember Catalyst A improved yield",
        source_trace_id="trace_1",
        source_message_id="msg_1",
        source_message_ids=["msg_1"],
        source_claim_ids=["claim_1"],
    )
    agent = AgentState(agent_id="a1", role="proposer", system_prompt="", memory=[memory])
    runtime = MemoryRuntime()

    assert runtime.quarantine_agent_memory(agent, "mem_lineage", "high_risk")
    assert memory.quarantined
    assert runtime.retrieve_for_agent(
        agent,
        DebateTask(task_id="t1", domain="factual", question="Catalyst A", ground_truth="Catalyst A improved yield"),
        [],
    ) == []

    assert runtime.rollback_agent_memory(agent, "mem_lineage", "lineage_contaminated")
    lineage = runtime.memory_lineage(memory)
    assert lineage["source_claim_ids"] == ["claim_1"]
    assert lineage["rolled_back"] is True


def test_memory_store_lineage_uses_runtime_semantics() -> None:
    memory = MemoryItem(memory_id="mem_shared", owner_agent_id="a1", scope="shared", content="verified conclusion", source_claim_ids=["claim_1"])
    store = MemoryStore([memory])

    store.rollback("mem_shared")

    assert store.lineage("mem_shared")["rolled_back"] is True
