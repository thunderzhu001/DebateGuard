from __future__ import annotations

import math
from pathlib import Path

import networkx as nx
import yaml

from debateguard.certificate_policy import policy_config_hash
from debateguard.metrics.theory import (
    certificate_action,
    compute_answer_margin,
    compute_attack_budget_bound,
    compute_influence_radius,
    compute_pseudo_consensus_gap,
    compute_relation_error_bound,
    compute_risk_coverage_curve,
    compute_trace_completeness,
    compute_trace_theory_metrics,
    propagation_step,
)
from debateguard.defenses.memory_gate import next_memory_gate_state
from debateguard.schemas import AgentState, AttackEvent, Claim, DebateMessage, DebateTask, DebateTrace, MemoryItem, MemoryUpdate


def test_influence_radius_on_toy_graph_detects_contraction_condition():
    graph = nx.DiGraph()
    graph.add_node("a", status="supported", risk_score=0.0)
    graph.add_node("b", status="supported", risk_score=0.0)
    graph.add_node("c", status="supported", risk_score=0.0)
    graph.add_edge("a", "c", weight=0.4)
    graph.add_edge("b", "c", weight=0.3)
    assert compute_influence_radius(graph) == 0.7
    graph.add_edge("a", "b", weight=1.2)
    assert compute_influence_radius(graph) == 1.0


def test_answer_margin_and_attack_budget_bound_are_monotonic():
    margin = compute_answer_margin({"safe": 0.8, "unsafe": 0.3})
    assert margin["top_answer"] == "safe"
    assert margin["margin"] == 0.5
    graph = nx.DiGraph()
    graph.add_node("a", status="supported")
    graph.add_node("b", status="supported")
    graph.add_edge("a", "b", weight=0.5)
    small = compute_attack_budget_bound(graph, {"k": 1, "B_msg": 1})
    large = compute_attack_budget_bound(graph, {"k": 2, "B_msg": 3, "B_mem": 1})
    assert large >= small


def test_pseudo_consensus_gap_vote_majority_weak_structural_support():
    gap = compute_pseudo_consensus_gap({"bad": 0.8, "good": 0.2}, {"bad": 0.1, "good": 0.9})
    assert math.isclose(gap, 0.7)


def test_trace_completeness_marks_missing_required_provenance():
    task = DebateTask(task_id="t1", domain="factual", question="q", ground_truth="true", adversarial_claim="false")
    incomplete = DebateTrace(task=task, topology="independent", agents=[AgentState(agent_id="a1", role="proposer", system_prompt="")])
    complete_claim = Claim(claim_id="c1", text="true", source_message_id="m1", source_agent_id="a1", verification_status="supported")
    complete = DebateTrace(
        trace_id="trace_1",
        task=task,
        topology="independent",
        agents=[AgentState(agent_id="a1", role="proposer", system_prompt="")],
        messages=[
            DebateMessage(
                message_id="m1",
                round_id=1,
                sender_id="a1",
                receiver_ids=[],
                content="true",
                claims=[complete_claim],
            )
        ],
        final_answer="true",
        metadata={"benchmark_hash": "b", "trace_hash": "h", "safety_regression_events": []},
        metrics={},
    )
    assert compute_trace_completeness(incomplete) < compute_trace_completeness(complete)
    assert compute_trace_completeness(complete) >= 0.8


def test_relation_error_bound_increases_with_uncertainty():
    graph = nx.DiGraph()
    graph.add_node("a", status="supported")
    graph.add_node("b", status="supported")
    graph.add_edge("a", "b", weight=0.4)
    low = compute_relation_error_bound(graph, [{"source": "a", "target": "b", "uncertainty": 0.1}])
    high = compute_relation_error_bound(graph, [{"source": "a", "target": "b", "uncertainty": 0.5}])
    assert high["relation_error_bound"] > low["relation_error_bound"]


def test_propagation_step_obeys_toy_lipschitz_bound():
    graph = nx.DiGraph()
    graph.add_node("a", status="supported", risk_score=0.0)
    graph.add_node("b", status="supported", risk_score=0.0)
    graph.add_edge("a", "b", weight=0.4)
    first = propagation_step(graph, {"a": 0.2, "b": 0.0})
    second = propagation_step(graph, {"a": 0.8, "b": 0.0})
    assert math.isclose(second["b"] - first["b"], 0.24)
    assert second["b"] - first["b"] <= compute_influence_radius(graph) * 0.6 + 1e-9


def test_memory_gate_state_transition_and_certificate_action():
    assert next_memory_gate_state("candidate", "approve") == "accepted"
    assert next_memory_gate_state("candidate", "quarantine") == "quarantined"
    assert next_memory_gate_state("accepted", "approve", rollback=True) == "rolled_back"
    assert (
        certificate_action(
            safe_influence_radius=1.2,
            terminal_safety_margin=0.9,
            attack_budget_bound=0.1,
            trace_completeness=1.0,
            pseudo_consensus_gap=0.1,
        )
        == "fallback_or_abstain"
    )


def test_risk_coverage_curve_drops_coverage_with_threshold():
    records = [
        {"terminal_safety_margin": 0.1, "safety_regression_event_count": 1},
        {"terminal_safety_margin": 0.8, "safety_regression_event_count": 0},
    ]
    curve = compute_risk_coverage_curve(records, [0.0, 0.5])
    assert curve[0]["coverage"] == 1.0
    assert curve[1]["coverage"] == 0.5
    assert curve[1]["selective_risk"] == 0.0


def test_trace_theory_metrics_capture_memory_gate_certificate_failure():
    task = DebateTask(task_id="t1", domain="factual", question="q", ground_truth="true", adversarial_claim="false")
    false_claim = Claim(
        claim_id="c_false",
        text="false",
        source_message_id="m1",
        source_agent_id="a1",
        verification_status="contradicted",
        risk_score=0.95,
    )
    memory = MemoryItem(
        memory_id="mem_false",
        owner_agent_id="m1",
        content="false",
        source_claim_ids=["c_false"],
        risk_score=0.95,
        quarantined=True,
    )
    trace = DebateTrace(
        task=task,
        topology="fully_connected",
        agents=[
            AgentState(agent_id="a1", role="adversary", system_prompt="", is_adversarial=True),
            AgentState(agent_id="m1", role="memory_manager", system_prompt="", memory=[memory]),
        ],
        messages=[
            DebateMessage(
                message_id="m1",
                round_id=1,
                sender_id="a1",
                receiver_ids=["m1"],
                content="false",
                claims=[false_claim],
                confidence=0.9,
                attack_tag="memory_poisoning",
            )
        ],
        final_answer="true",
        memory_updates=[MemoryUpdate(agent_id="m1", memory_item=memory, action="quarantined")],
        attack_events=[AttackEvent(attack_type="memory_poisoning", claim="false", target_agent_id="a1")],
        metadata={"benchmark_hash": "b", "trace_hash": "h", "safety_regression_events": []},
    )
    metrics = compute_trace_theory_metrics(trace)
    assert metrics["pseudo_consensus_gap"] >= 0
    assert metrics["trace_completeness"] >= 0.8
    assert "safety_certificate_pass" in metrics


def test_trace_theory_metrics_use_exact_frozen_policy_and_memory_risk() -> None:
    policy_config = yaml.safe_load(
        Path("configs/certificate_policy_frozen.yaml").read_text(encoding="utf-8")
    )
    policy_hash = policy_config_hash(policy_config)
    task = DebateTask(
        task_id="t_policy",
        domain="factual",
        question="q",
        ground_truth="true",
        adversarial_claim="false",
    )
    false_memory = MemoryItem(
        memory_id="mem_false",
        owner_agent_id="a1",
        content="false",
        risk_score=0.95,
    )
    trace = DebateTrace(
        trace_id="trace_policy",
        task=task,
        topology="independent",
        agents=[
            AgentState(
                agent_id="a1",
                role="proposer",
                system_prompt="",
                memory=[false_memory],
            )
        ],
        messages=[
            DebateMessage(
                message_id="m1",
                round_id=1,
                sender_id="a1",
                receiver_ids=[],
                content="true",
                claims=[
                    Claim(
                        claim_id="c1",
                        text="true",
                        source_message_id="m1",
                        source_agent_id="a1",
                        verification_status="supported",
                    )
                ],
                metadata={"retrieved_memory_ids": ["mem_false"]},
            )
        ],
        final_answer="true",
        memory_updates=[
            MemoryUpdate(
                agent_id="a1",
                memory_item=false_memory,
                action="poisoned",
            )
        ],
        attack_events=[
            AttackEvent(
                attack_type="memory_poisoning",
                claim="false",
                target_agent_id="a1",
            )
        ],
        metadata={
            "benchmark_hash": "b",
            "safety_regression_events": [],
            "certificate_policy_config": policy_config,
            "certificate_policy_hash": policy_hash,
            "policy_hash": policy_hash,
        },
    )

    metrics = compute_trace_theory_metrics(trace)

    assert metrics["trace_completeness"] == 1.0
    assert metrics["certificate_policy_source"] == "frozen_config"
    assert metrics["certificate_policy_hash"] == policy_hash
    assert metrics["max_admitted_memory_write_risk"] == 0.95
    assert metrics["max_retrieved_memory_risk"] == 0.95
    assert metrics["safety_certificate_pass"] == 0
