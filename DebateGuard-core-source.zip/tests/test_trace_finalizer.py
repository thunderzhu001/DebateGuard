from __future__ import annotations

from debateguard.schemas import AgentState, Claim, DebateMessage, DebateTask, DebateTrace, DefenseEvent, MemoryItem, MemoryUpdate
from debateguard.tracing import TraceFinalizer


def test_trace_finalizer_remaps_provenance_ids_consistently() -> None:
    task = DebateTask(task_id="t1", domain="factual", question="q", ground_truth="true answer")
    claim = Claim(claim_id="old_claim", text="true answer", source_message_id="old_msg", source_agent_id="a1")
    memory = MemoryItem(
        memory_id="old_mem",
        owner_agent_id="a1",
        content="Remember true answer",
        source_message_id="old_msg",
        source_message_ids=["old_msg"],
        source_claim_ids=["old_claim"],
    )
    trace = DebateTrace(
        experiment_name="exp",
        episode_id=2,
        seed=7,
        task=task,
        topology="fully_connected",
        agents=[AgentState(agent_id="a1", role="proposer", system_prompt="", memory=[memory])],
        messages=[
            DebateMessage(
                message_id="old_msg",
                round_id=1,
                sender_id="a1",
                receiver_ids=[],
                content="My answer is true answer.",
                claims=[claim],
                claim_ids=["old_claim"],
                metadata={"retrieved_memory_ids": ["old_mem"], "role": "proposer"},
            )
        ],
        memory_updates=[MemoryUpdate(update_id="old_update", agent_id="a1", memory_item=memory)],
        defense_events=[DefenseEvent(event_id="old_defense", defense_type="risk", target_id="old_claim", action="flag")],
        accepted_claim_ids=["old_claim"],
        metadata={
            "debateguard": {
                "risky_claims": [{"claim_id": "old_claim"}],
                "attribution": [{"suspected_source_id": "old_msg"}],
            }
        },
    )

    TraceFinalizer().finalize(trace)

    assert trace.trace_id == "trace_exp_ep2_t1"
    assert trace.messages[0].message_id == "msg_ep2_0001"
    assert trace.messages[0].claims[0].claim_id == "claim_msg_ep2_0001_01"
    assert trace.memory_updates[0].memory_item.memory_id == "mem_ep2_001"
    assert trace.messages[0].metadata["retrieved_memory_ids"] == ["mem_ep2_001"]
    assert trace.defense_events[0].target_id == "claim_msg_ep2_0001_01"
    assert trace.metadata["debateguard"]["risky_claims"][0]["claim_id"] == "claim_msg_ep2_0001_01"
    assert trace.metadata["debateguard"]["attribution"][0]["suspected_source_id"] == "msg_ep2_0001"
