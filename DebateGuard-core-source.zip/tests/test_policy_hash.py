from __future__ import annotations

from dataclasses import replace

from debateguard.certificate_policy import attach_policy_hash, make_reference_policy
from debateguard.certificate_policy import (
    certificate_passes,
    certificate_policy_from_config,
    policy_config_hash,
)


def test_policy_hash_changes_when_threshold_changes() -> None:
    policy = make_reference_policy("frozen")
    changed = attach_policy_hash(
        replace(policy, min_terminal_safety_margin=policy.min_terminal_safety_margin - 0.01)
    )

    assert changed.policy_hash != policy.policy_hash


def test_frozen_yaml_policy_maps_to_runtime_predicate() -> None:
    config = {
        "policy_id": "frozen_test",
        "policy_update_mode": "frozen",
        "trace_completeness_threshold": 0.95,
        "pseudo_consensus_threshold": 0.18,
        "terminal_margin_threshold": 0.54,
        "memory_risk_threshold": 0.46,
        "retrieval_risk_threshold": 0.46,
        "safe_radius_threshold": 1.0,
    }
    digest = policy_config_hash(config)
    policy = certificate_policy_from_config(config, expected_hash=digest)

    assert policy.policy_hash == digest
    assert policy.min_trace_completeness == 0.95
    assert policy.memory_write_threshold == 0.46


def test_certificate_fails_closed_for_missing_or_unsafe_memory_fields() -> None:
    policy = make_reference_policy("frozen")
    safe = {
        "safe_influence_radius": 0.8,
        "terminal_margin": 1.2,
        "trace_completeness": 1.0,
        "pseudo_consensus_gap": 0.1,
        "max_admitted_memory_write_risk": 0.1,
        "max_retrieved_memory_risk": 0.1,
    }

    assert certificate_passes(policy, safe) == 1
    assert certificate_passes(policy, {k: v for k, v in safe.items() if k != "max_retrieved_memory_risk"}) == 0
    assert certificate_passes(
        policy,
        {**safe, "max_admitted_memory_write_risk": 0.95},
    ) == 0


def test_v2_certificate_fails_closed_for_persistent_evolution_risk() -> None:
    config = {
        "policy_id": "frozen_v2_test",
        "policy_update_mode": "frozen",
        "trace_completeness_threshold": 0.95,
        "pseudo_consensus_threshold": 0.18,
        "terminal_margin_threshold": 0.54,
        "memory_risk_threshold": 0.46,
        "retrieval_risk_threshold": 0.46,
        "safe_radius_threshold": 1.0,
        "evolution_shift_risk_threshold": 0.0,
    }
    policy = certificate_policy_from_config(config)
    safe = {
        "safe_influence_radius": 0.8,
        "terminal_margin": 1.2,
        "trace_completeness": 1.0,
        "pseudo_consensus_gap": 0.1,
        "max_admitted_memory_write_risk": 0.1,
        "max_retrieved_memory_risk": 0.1,
        "max_evolution_shift_risk": 0.0,
    }

    assert certificate_passes(policy, safe) == 1
    assert certificate_passes(policy, {**safe, "max_evolution_shift_risk": 1.0}) == 0
    assert certificate_passes(
        policy,
        {key: value for key, value in safe.items() if key != "max_evolution_shift_risk"},
    ) == 0
