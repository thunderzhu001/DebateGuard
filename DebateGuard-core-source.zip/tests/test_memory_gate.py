from debateguard.defenses.memory_gate import MemoryRegressionGate
from debateguard.schemas import MemoryItem


def test_memory_gate_quarantines_adversarial_claim():
    item = MemoryItem(owner_agent_id="m1", content="Remember false answer", verified=False)
    decision = MemoryRegressionGate().decide(item, adversarial_claim="false answer", attack_active=True)
    assert decision.decision == "quarantine"
    assert "contains_adversarial_claim" in decision.reasons

